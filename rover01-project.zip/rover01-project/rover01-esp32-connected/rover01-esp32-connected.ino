/*
  ==========================================================================
  ROVER-01 — ESP32 4WD, now CONNECTED to the admin/customer web backend
  ==========================================================================

  This builds on rover01-esp32-4wd.ino by adding one thing: the ESP32 now
  also joins your HOME WiFi and polls your backend server (the one running
  on your PC with `npm start`) to find out what the admin dashboard wants
  it to do. It keeps its own local "RobotCar" hotspot running too, as a
  backup way to control it directly from a phone.

  EXTRA LIBRARY YOU NEED (Arduino IDE -> Library Manager):
    - "ArduinoJson" by Benoit Blanchon (search "ArduinoJson", install the
      latest 6.x or 7.x version)

  BEFORE UPLOADING, FILL IN THESE THREE THINGS BELOW:
    1. HOME_WIFI_SSID / HOME_WIFI_PASSWORD — your actual home WiFi
    2. BACKEND_HOST — your computer's local IP address on that same WiFi
       (Windows: open a terminal and run `ipconfig`, look for "IPv4
        Address" under your WiFi adapter — something like 192.168.1.50)
    3. Make sure `npm start` is already running in your backend folder
       BEFORE you power on the robot, and that Windows Firewall allows
       Node.js to accept connections (it usually asks the first time you
       run the server — click "Allow").

  Everything else (motor pins, obstacle avoidance, local web page) is
  identical to rover01-esp32-4wd.ino.
  ==========================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <ESP32Servo.h>

// ---------------- USER SETTINGS ----------------
const char* AP_SSID       = "RobotCar";       // local backup hotspot (unchanged)
const char* AP_PASSWORD   = "robot1234";

const char* HOME_WIFI_SSID     = "YOUR_HOME_WIFI_NAME";       // <-- fill this in
const char* HOME_WIFI_PASSWORD = "YOUR_HOME_WIFI_PASSWORD";   // <-- fill this in
const char* BACKEND_HOST       = "192.168.1.50";              // <-- your PC's IPv4 address
const int   BACKEND_PORT       = 4000;

const int   OBSTACLE_DISTANCE_CM = 20;

// ---------------- MOTOR PINS (same as rover01-esp32-4wd.ino) ----------------
const int IN1 = 5,  IN2 = 18;
const int IN3 = 19, IN4 = 21;
const int ENA = 22;
const int ENB = 23;

const bool SWAP_SIDES   = false;
const bool INVERT_LEFT  = false;
const bool INVERT_RIGHT = false;

const int TRIG_PIN  = 25;
const int ECHO_PIN  = 26;
const int SERVO_PIN = 27;
Servo scanServo;

WebServer server(80);
bool autoMode      = false;
int  currentSpeed  = 700;
const int AUTO_SPEED = 600;
const int BACKUP_TIME_MS = 1200;
const int MAX_ESCAPE_ATTEMPTS = 4;

long lastFrontDistance = 999;

// ==========================================================================
// PWM
// ==========================================================================
const int PWM_FREQ = 5000;
const int PWM_RESOLUTION = 8;
void setupPWM() {
  ledcAttach(ENA, PWM_FREQ, PWM_RESOLUTION);
  ledcAttach(ENB, PWM_FREQ, PWM_RESOLUTION);
}
void pwmWrite(int pin, int value) { ledcWrite(pin, value); }

// ==========================================================================
// MOTOR CONTROL
// ==========================================================================
void setLeftMotorRaw(int speed, bool forward) {
  pwmWrite(ENA, speed);
  digitalWrite(IN1, forward ? HIGH : LOW);
  digitalWrite(IN2, forward ? LOW  : HIGH);
}
void setRightMotorRaw(int speed, bool forward) {
  pwmWrite(ENB, speed);
  digitalWrite(IN3, forward ? HIGH : LOW);
  digitalWrite(IN4, forward ? LOW  : HIGH);
}
void setLeftMotor(int speed, bool forward) {
  bool f = forward != INVERT_LEFT;
  if (SWAP_SIDES) setRightMotorRaw(speed, f); else setLeftMotorRaw(speed, f);
}
void setRightMotor(int speed, bool forward) {
  bool f = forward != INVERT_RIGHT;
  if (SWAP_SIDES) setLeftMotorRaw(speed, f); else setRightMotorRaw(speed, f);
}
void stopMotors() {
  pwmWrite(ENA, 0); pwmWrite(ENB, 0);
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
}
void moveForward(int s)  { setLeftMotor(s, true);  setRightMotor(s, true);  }
void moveBackward(int s) { setLeftMotor(s, false); setRightMotor(s, false); }
void turnLeft(int s)     { setLeftMotor(s, false); setRightMotor(s, true);  }
void turnRight(int s)    { setLeftMotor(s, true);  setRightMotor(s, false); }

// Shared by the local web page AND the backend polling, so both control
// paths behave identically.
void applyCommand(const String& action) {
  if (autoMode) return; // ignore manual commands while in auto-nav mode
  if (action == "forward")       moveForward(currentSpeed);
  else if (action == "backward") moveBackward(currentSpeed);
  else if (action == "left")     turnLeft(currentSpeed);
  else if (action == "right")    turnRight(currentSpeed);
  else if (action == "stop")     stopMotors();
}

// ==========================================================================
// ULTRASONIC + OBSTACLE AVOIDANCE (unchanged from rover01-esp32-4wd.ino)
// ==========================================================================
long readDistanceRaw() {
  digitalWrite(TRIG_PIN, LOW); delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return 999;
  return duration * 0.034 / 2;
}
long readDistanceCM() {
  long a = readDistanceRaw(); delay(15);
  long b = readDistanceRaw(); delay(15);
  long c = readDistanceRaw();
  if (a > b) { long t=a; a=b; b=t; }
  if (b > c) { long t=b; b=c; c=t; }
  if (a > b) { long t=a; a=b; b=t; }
  return b;
}

long distAngle[5];
const int scanAngles[5] = {160, 125, 90, 55, 20};
void sweepAndRead() {
  for (int i = 0; i < 5; i++) {
    scanServo.write(scanAngles[i]);
    delay(i == 0 ? 300 : 180);
    distAngle[i] = readDistanceCM();
  }
  scanServo.write(90); delay(150);
}
int pickBestIndex() {
  int bestIndex = 2;
  for (int i = 0; i < 5; i++) {
    if (distAngle[i] > distAngle[bestIndex]) bestIndex = i;
    else if (distAngle[i] == distAngle[bestIndex] && abs(i-2) < abs(bestIndex-2)) bestIndex = i;
  }
  return bestIndex;
}
void steerToward(int bestIndex) {
  if (bestIndex == 2) { moveForward(AUTO_SPEED); delay(300); }
  else if (bestIndex < 2) { turnLeft(AUTO_SPEED); delay(300 + (2-bestIndex)*120); }
  else { turnRight(AUTO_SPEED); delay(300 + (bestIndex-2)*120); }
  stopMotors();
}
void obstacleAvoid() {
  long distFront = readDistanceCM();
  lastFrontDistance = distFront;
  if (distFront > OBSTACLE_DISTANCE_CM) { moveForward(AUTO_SPEED); return; }
  stopMotors(); delay(80);
  for (int attempt = 0; attempt < MAX_ESCAPE_ATTEMPTS; attempt++) {
    sweepAndRead();
    int bestIndex = pickBestIndex();
    if (distAngle[bestIndex] > OBSTACLE_DISTANCE_CM) { steerToward(bestIndex); return; }
    moveBackward(AUTO_SPEED); delay(BACKUP_TIME_MS); stopMotors(); delay(300);
    sweepAndRead();
    bestIndex = pickBestIndex();
    if (distAngle[bestIndex] > OBSTACLE_DISTANCE_CM) { steerToward(bestIndex); return; }
  }
  turnRight(AUTO_SPEED); delay(500); stopMotors();
}

// ==========================================================================
// BACKEND POLLING — the new part
// ==========================================================================
unsigned long lastPollTime = 0;
unsigned long lastTelemetryTime = 0;
const unsigned long POLL_INTERVAL_MS = 300;
const unsigned long TELEMETRY_INTERVAL_MS = 2000;

void pollBackend() {
  if (WiFi.status() != WL_CONNECTED) return; // not on home WiFi, skip

  HTTPClient http;
  String url = String("http://") + BACKEND_HOST + ":" + BACKEND_PORT + "/api/robot/poll";
  http.begin(url);
  http.setTimeout(1000);
  int code = http.GET();

  if (code == 200) {
    String body = http.getString();
    StaticJsonDocument<256> doc;
    if (deserializeJson(doc, body) == DeserializationError::Ok) {
      bool wantsAuto = doc["mode"]["auto"] | false;
      String action = doc["command"]["action"] | "stop";
      autoMode = wantsAuto;
      if (!autoMode) applyCommand(action);
    }
  }
  http.end();
}

void postTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = String("http://") + BACKEND_HOST + ":" + BACKEND_PORT + "/api/robot/telemetry";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  String payload = String("{\"battery\":") + "100" // no battery sensor wired yet — placeholder
                    + ",\"distanceCm\":" + lastFrontDistance + "}";
  http.POST(payload);
  http.end();
}

// ==========================================================================
// LOCAL WEB PAGES (backup control) — same as rover01-esp32-4wd.ino
// ==========================================================================
void handleRoot() {
  server.send(200, "text/html",
    "<h2>ROVER-01 local backup control</h2>"
    "<p>Use the admin dashboard on your computer for full control. "
    "This page is a simple fallback.</p>"
    "<button onclick=\"fetch('/cmd?action=forward')\">Forward</button> "
    "<button onclick=\"fetch('/cmd?action=backward')\">Backward</button> "
    "<button onclick=\"fetch('/cmd?action=left')\">Left</button> "
    "<button onclick=\"fetch('/cmd?action=right')\">Right</button> "
    "<button onclick=\"fetch('/cmd?action=stop')\">Stop</button>");
}
void handleCmd() {
  applyCommand(server.arg("action"));
  server.send(200, "text/plain", "OK");
}
void handleMode() {
  if (server.hasArg("auto")) { autoMode = server.arg("auto") == "1"; stopMotors(); }
  server.send(200, "text/plain", "OK");
}

// ==========================================================================
// SETUP
// ==========================================================================
void setup() {
  Serial.begin(115200);

  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  setupPWM();
  stopMotors();

  // Run BOTH a local hotspot (backup control) AND join home WiFi (for the backend)
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  Serial.print("Backup hotspot started: "); Serial.println(AP_SSID);
  Serial.print("Backup control page: http://"); Serial.println(WiFi.softAPIP());

  Serial.print("Connecting to home WiFi: "); Serial.println(HOME_WIFI_SSID);
  WiFi.begin(HOME_WIFI_SSID, HOME_WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(300);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.print("Connected to home WiFi. ESP32 IP: "); Serial.println(WiFi.localIP());
    Serial.print("Will poll backend at: http://"); Serial.print(BACKEND_HOST); Serial.print(":"); Serial.println(BACKEND_PORT);
  } else {
    Serial.println();
    Serial.println("Could NOT connect to home WiFi — check SSID/password. Falling back to local hotspot control only.");
  }

  server.on("/", handleRoot);
  server.on("/cmd", handleCmd);
  server.on("/mode", handleMode);
  server.begin();

  scanServo.attach(SERVO_PIN);
  scanServo.write(90);
  delay(300);
}

// ==========================================================================
// LOOP
// ==========================================================================
void loop() {
  server.handleClient();

  unsigned long now = millis();
  if (now - lastPollTime >= POLL_INTERVAL_MS) {
    lastPollTime = now;
    pollBackend();
  }
  if (now - lastTelemetryTime >= TELEMETRY_INTERVAL_MS) {
    lastTelemetryTime = now;
    postTelemetry();
  }

  if (autoMode) {
    obstacleAvoid();
  }
}
