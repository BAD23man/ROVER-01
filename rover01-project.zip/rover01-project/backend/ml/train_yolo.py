"""
ROVER-01 — Path B: training a REAL crop-ripeness model (the upgrade
path from the color-based detector in color_ripeness_detector.py).

DO NOT RUN THIS YET if you haven't collected and labeled your own
photos — it needs real data to train on. This file is here so it's
ready the moment you have that data, not something to run today.

------------------------------------------------------------------------
STEP 1 — COLLECT PHOTOS (this is on you, not code)
------------------------------------------------------------------------
Take 200-500+ photos of your actual crop, covering:
  - Every ripeness stage you care about (unripe, nearly ripe, ripe)
  - Different times of day / lighting conditions
  - Different angles and distances
  - Some cluttered/realistic shots, not just clean close-ups
More variety = a model that actually generalizes instead of memorizing
your exact test photos. This is genuinely the most important step —
a great training script can't fix a small or unrepresentative dataset.

------------------------------------------------------------------------
STEP 2 — LABEL THE PHOTOS (free tools)
------------------------------------------------------------------------
Use Roboflow (roboflow.com, free tier) or LabelImg (free, runs locally).
For each photo, draw a box around each fruit and tag it with its class:
"ripe", "nearly_ripe", or "unripe" — whatever labels match your crop.

Roboflow specifically is worth using because it can export directly in
"YOLO format," which is exactly what this script expects — it also has
a free "Train" button that does everything below for you automatically,
if you'd rather skip running this script yourself entirely.

------------------------------------------------------------------------
STEP 3 — TRAIN (this script), using Google Colab's free GPU
------------------------------------------------------------------------
1. Go to colab.research.google.com, create a new notebook
2. Runtime -> Change runtime type -> GPU (free tier is fine for this)
3. Upload your labeled dataset (as a .zip from Roboflow's export)
4. In a Colab cell, run:
     !pip install ultralytics
     !unzip your_dataset.zip -d dataset
5. Paste the code below into a cell and run it
6. Download the resulting best.pt file when training finishes

------------------------------------------------------------------------
STEP 4 — SWAP IT INTO YOUR PIPELINE
------------------------------------------------------------------------
Once you have best.pt, replace the import in inference_server.py:

    from color_ripeness_detector import detect_crops

with a YOLO-based version (see detect_crops_yolo() below) — everything
else in inference_server.py (grabbing frames, posting to the backend)
stays exactly the same. That's the whole point of keeping the same
function signature: swapping the brain doesn't require rewriting the
plumbing around it.
"""

# ---------------------------------------------------------------------------
# TRAINING CODE — run this in Google Colab once you have labeled data
# ---------------------------------------------------------------------------
TRAINING_CODE = """
from ultralytics import YOLO

# Start from a small pretrained model (fast, good for a free-tier GPU,
# and works well even with a modest dataset size thanks to transfer
# learning) rather than training from nothing.
model = YOLO('yolo11n.pt')

results = model.train(
    data='dataset/data.yaml',   # this file comes from your Roboflow export
    epochs=100,
    imgsz=640,
    batch=16,
    patience=20,                 # stop early if it's not improving anymore
    name='rover01-crop-ripeness'
)

# The trained model lands at:
#   runs/detect/rover01-crop-ripeness/weights/best.pt
# Download that file — it's what inference_server.py will load.
"""


# ---------------------------------------------------------------------------
# INFERENCE CODE — once you have best.pt, this REPLACES
# color_ripeness_detector.py's detect_crops() with the same interface,
# so inference_server.py doesn't need to change at all except one import
# line.
# ---------------------------------------------------------------------------
def detect_crops_yolo(image_bgr, model_path='best.pt'):
    """
    Same return shape as detect_crops() in color_ripeness_detector.py:
    a list of { 'bbox', 'status', 'confidencePct', 'harvestInDays' }.

    Requires: pip install ultralytics
    """
    from ultralytics import YOLO

    # Loading the model fresh on every call is wasteful — in real use,
    # load it once at the top of inference_server.py and pass it in,
    # rather than reloading it every 15 seconds in the check loop.
    model = YOLO(model_path)

    # Map your training labels to the same harvest-days estimates used
    # by the color-based version, so the rest of the app doesn't care
    # which detector produced the reading.
    HARVEST_DAYS = {'ripe': 0, 'nearly_ripe': 3, 'unripe': 10}
    LABELS = {'ripe': 'Ripe', 'nearly_ripe': 'Nearly ripe', 'unripe': 'Unripe'}

    results = model(image_bgr, verbose=False)[0]
    detections = []
    for box in results.boxes:
        class_name = model.names[int(box.cls[0])]
        confidence = float(box.conf[0]) * 100
        x1, y1, x2, y2 = box.xyxy[0].tolist()
        detections.append({
            'bbox': (int(x1), int(y1), int(x2 - x1), int(y2 - y1)),
            'status': LABELS.get(class_name, class_name),
            'confidencePct': round(confidence, 1),
            'harvestInDays': HARVEST_DAYS.get(class_name, None)
        })
    return detections


if __name__ == '__main__':
    print(__doc__)
    print("\n--- Training code to paste into Google Colab ---")
    print(TRAINING_CODE)
