"""
ROVER-01 — Color-based crop ripeness detector.

No trained model, no dataset, no GPU needed — this works TODAY by
analyzing color. Tomatoes (and most fruit) shift color as they ripen:
green -> orange -> red. This finds fruit-colored blobs in a photo and
classifies each one by its dominant hue.

This is intentionally the "good enough to be genuinely useful" tier —
see train_yolo.py in this same folder for the upgrade path to a real
trained model once you've collected your own labeled photos.

HOW IT WORKS
------------------------------------------------------------------------
1. Convert the image to HSV color space (Hue/Saturation/Value) — hue is
   what actually captures "redness" vs "greenness" independent of
   lighting brightness, which is why this works better than plain
   RGB color matching.
2. Build a mask for pixels that look like "any stage of tomato" (covers
   green through red hues, with reasonable saturation so it doesn't
   pick up dull background colors).
3. Find contours (blobs) in that mask — each blob is a candidate fruit.
4. For each blob big enough to matter, measure ITS average hue and
   classify: red-ish -> Ripe, orange-ish -> Nearly ripe, green -> Unripe.
5. Confidence is based on how strongly the blob's pixels agree with
   each other on hue (a clean, uniform-colored blob = high confidence;
   a mixed/noisy blob = lower confidence) — this is a real, computed
   number, not a fake one.

LIMITATIONS (be aware of these)
------------------------------------------------------------------------
- Only knows color, not shape — a red leaf or red plastic tag in frame
  could get misread as a ripe tomato. Point the camera at crop rows
  specifically, not a busy background, to minimize this.
- Lighting matters. Very yellow/orange grow-lights can shift what the
  camera sees as "orange" vs "red". If readings look consistently off,
  adjust the HUE_RANGES below to match your actual lighting.
- No per-fruit tracking between frames — each photo is analyzed fresh,
  so the same tomato might get a new ID each time rather than being
  recognized as "the same one as last check." Good enough for a general
  ripeness overview of the row; not for individually tracking one fruit
  over weeks.
"""

import cv2
import numpy as np

# ---------------------------------------------------------------------------
# CROP PRESETS — each crop ripens through different colors, so each gets
# its own hue ranges and harvest-day estimates. Values are OpenCV-style
# HSV: H: 0-179, S: 0-255, V: 0-255.
#
# Pick the closest match to what you're growing, or add your own preset
# below — point a camera at your actual crop, note the colors at each
# ripeness stage, and adjust the ranges to match.
# ---------------------------------------------------------------------------
CROP_PRESETS = {
    'tomato': {
        'label': 'Tomato',
        'hue_ranges': {
            'ripe':   [(0, 10), (170, 179)],   # red
            'nearly': [(11, 20)],               # orange
            'unripe': [(35, 85)],               # green
        },
        'harvest_days': {'ripe': 0, 'nearly': 3, 'unripe': 10},
    },
    'pepper': {
        'label': 'Pepper (bell/chili)',
        'hue_ranges': {
            'ripe':   [(0, 8), (172, 179)],    # red
            'nearly': [(9, 22)],                 # orange/yellow
            'unripe': [(35, 85)],               # green
        },
        'harvest_days': {'ripe': 0, 'nearly': 4, 'unripe': 14},
    },
    'banana': {
        'label': 'Banana',
        'hue_ranges': {
            'ripe':   [(24, 32)],               # yellow
            'nearly': [(33, 39)],               # yellow-green transition
            'unripe': [(40, 85)],               # green
        },
        'harvest_days': {'ripe': 0, 'nearly': 5, 'unripe': 12},
    },
    'mango': {
        'label': 'Mango',
        'hue_ranges': {
            'ripe':   [(0, 15), (170, 179)],   # red-orange blush
            'nearly': [(16, 30)],               # yellow-orange
            'unripe': [(40, 85)],               # green
        },
        'harvest_days': {'ripe': 0, 'nearly': 6, 'unripe': 18},
    },
    'coffee': {
        'label': 'Coffee cherry',
        'hue_ranges': {
            'ripe':   [(0, 10), (170, 179)],   # deep red
            'nearly': [(11, 20)],               # orange-red
            'unripe': [(35, 85)],               # green
        },
        'harvest_days': {'ripe': 0, 'nearly': 5, 'unripe': 20},
    },
    'strawberry': {
        'label': 'Strawberry',
        'hue_ranges': {
            'ripe':   [(0, 8), (172, 179)],    # red
            'nearly': [(9, 18)],                 # pink-orange
            'unripe': [(35, 85)],               # green
        },
        'harvest_days': {'ripe': 0, 'nearly': 2, 'unripe': 6},
    },
}
DEFAULT_CROP = 'tomato'

MIN_SATURATION = 70   # ignore washed-out/grayish pixels (likely not fruit)
MIN_VALUE = 40         # ignore near-black shadow pixels
MIN_BLOB_AREA = 300    # ignore tiny specks (pixels) — raise this if you get noise

STATUS_LABELS = {'ripe': 'Ripe', 'nearly': 'Nearly ripe', 'unripe': 'Unripe'}


def _hue_mask(hsv, ranges):
    mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
    for lo, hi in ranges:
        lower = np.array([lo, MIN_SATURATION, MIN_VALUE])
        upper = np.array([hi, 255, 255])
        mask |= cv2.inRange(hsv, lower, upper)
    return mask


def detect_crops(image_bgr, crop_type=DEFAULT_CROP):
    """
    Takes an OpenCV BGR image (e.g. from cv2.imread or a decoded camera
    frame) and which crop preset to use (see CROP_PRESETS above — falls
    back to the tomato preset if crop_type isn't recognized).

    Returns a list of dicts, one per detected fruit:
        { 'bbox': (x, y, w, h), 'status': 'Ripe'|'Nearly ripe'|'Unripe',
          'confidencePct': float, 'harvestInDays': int }
    """
    preset = CROP_PRESETS.get(crop_type, CROP_PRESETS[DEFAULT_CROP])
    hue_ranges_by_status = preset['hue_ranges']
    harvest_days = preset['harvest_days']

    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)

    detections = []
    for key, ranges in hue_ranges_by_status.items():
        mask = _hue_mask(hsv, ranges)
        # Clean up small noise, close small gaps within a blob
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            area = cv2.contourArea(c)
            if area < MIN_BLOB_AREA:
                continue
            x, y, w, h = cv2.boundingRect(c)

            # Confidence: how uniform is the hue within this blob?
            blob_mask = np.zeros(mask.shape, dtype=np.uint8)
            cv2.drawContours(blob_mask, [c], -1, 255, -1)
            hue_values = hsv[:, :, 0][blob_mask == 255].astype(np.float64)
            if len(hue_values) == 0:
                continue
            # Red wraps around 0/179 — a naive std-dev across that seam
            # looks artificially huge (e.g. hues of 2 and 178 are actually
            # only 4 degrees apart, not 176). Shift high values down before
            # measuring spread so wrap-around doesn't fake low confidence.
            if key == 'ripe':
                hue_values = np.where(hue_values > 90, hue_values - 180, hue_values)
            hue_std = float(np.std(hue_values))
            # Lower std = more uniform color = higher confidence.
            # This mapping is a reasonable heuristic, not a calibrated
            # probability — tune the scale factor if it feels off.
            confidence = max(50.0, min(99.0, 99.0 - hue_std * 2.2))

            detections.append({
                'bbox': (int(x), int(y), int(w), int(h)),
                'status': STATUS_LABELS[key],
                'confidencePct': round(confidence, 1),
                'harvestInDays': harvest_days[key],
                'area': int(area)
            })

    # Largest blobs first — usually the clearest, most reliable detections
    detections.sort(key=lambda d: -d['area'])
    return detections


if __name__ == '__main__':
    # Guard against the exact bug this file used to have: overlapping hue
    # ranges within one crop preset cause a single fruit to be detected
    # twice, once under each overlapping status. Check every preset for
    # this before running anything else.
    def _ranges_overlap(a, b):
        return a[0] <= b[1] and b[0] <= a[1]

    overlap_found = False
    for crop_type, preset in CROP_PRESETS.items():
        flat = [(status, r) for status, ranges in preset['hue_ranges'].items() for r in ranges]
        for i in range(len(flat)):
            for j in range(i + 1, len(flat)):
                (status_a, range_a), (status_b, range_b) = flat[i], flat[j]
                if status_a != status_b and _ranges_overlap(range_a, range_b):
                    print(f"OVERLAP BUG: '{crop_type}' preset has {status_a}={range_a} "
                          f"overlapping {status_b}={range_b}")
                    overlap_found = True
    if not overlap_found:
        print("Overlap check passed — no crop preset has ambiguous overlapping hue ranges.\n")


    # Quick self-test with a synthetic image so you can confirm this
    # actually works before pointing it at a real camera. Draws a red
    # circle (ripe), an orange circle (nearly ripe), and a green circle
    # (unripe) on a plain background, then checks all three are found —
    # repeated for a few different crop presets to confirm the preset
    # system actually switches behavior, not just accepts the parameter.
    img = np.full((400, 600, 3), (95, 100, 90), dtype=np.uint8)  # desaturated soil-brown background
    cv2.circle(img, (100, 200), 50, (40, 40, 200), -1)   # BGR red   -> ripe
    cv2.circle(img, (300, 200), 50, (30, 130, 220), -1)  # BGR orange -> nearly ripe
    cv2.circle(img, (500, 200), 50, (50, 160, 60), -1)   # BGR green -> unripe

    all_passed = True
    for crop_type in ['tomato', 'pepper', 'coffee', 'strawberry']:
        preset_label = CROP_PRESETS[crop_type]['label']
        results = detect_crops(img, crop_type=crop_type)
        statuses_found = sorted(r['status'] for r in results)
        expected = sorted(['Ripe', 'Nearly ripe', 'Unripe'])
        passed = statuses_found == expected
        all_passed = all_passed and passed
        print(f"[{preset_label:20s}] found {len(results)} crop(s): {statuses_found} "
              f"-> {'PASS' if passed else 'FAIL (expected ' + str(expected) + ')'}")

    # Banana ripens green -> yellow, no red/orange stage — a genuinely
    # different color story, so test it with a yellow circle instead.
    img_banana = np.full((400, 300, 3), (95, 100, 90), dtype=np.uint8)
    cv2.circle(img_banana, (100, 200), 50, (30, 210, 220), -1)  # BGR yellow -> ripe
    cv2.circle(img_banana, (220, 200), 50, (50, 160, 60), -1)   # BGR green -> unripe
    banana_results = detect_crops(img_banana, crop_type='banana')
    banana_statuses = sorted(set(r['status'] for r in banana_results))
    print(f"[{'Banana':20s}] found {len(banana_results)} crop(s): {banana_statuses}")

    print("\n" + ("Self-test PASSED across all tested crop presets." if all_passed
                   else "Self-test had failures — check output above."))
