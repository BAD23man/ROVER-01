"""
ROVER-01 — Crop detection inference server.

This is the missing piece between "a detector that works on one image"
and "the farming-tracking.html page shows real readings instead of
simulated ones." It:

  1. Grabs a frame from your ESP32-CAM's stream periodically
  2. Runs it through color_ripeness_detector.py (swap this for a trained
     model later — see train_yolo.py — without changing anything else
     in this file)
  3. POSTs each detection to your Node backend's existing
     /api/crop-readings endpoint — the same endpoint the SIMULATED
     readings currently use

Run this on your own PC (or a Raspberry Pi later) — NOT on the ESP32
itself, which doesn't have the compute for this.

SETUP
------------------------------------------------------------------------
    pip install -r requirements.txt
    python inference_server.py

Then edit the CONFIG section below with your actual values.

ONCE THIS IS RUNNING
------------------------------------------------------------------------
Open public/farming-tracking.html and comment out or delete the
`setInterval(simulateCropReading, 5000);` line — that's the fake data
generator. With this script running, real readings will already be
flowing into the same log via Socket.IO, so the simulated ones would
otherwise show up mixed in alongside real ones.
"""

import time
import logging
import requests
import cv2
import numpy as np

from color_ripeness_detector import detect_crops

# ---------------------------------------------------------------------------
# CONFIG — fill these in
# ---------------------------------------------------------------------------
# CAMERA SOURCE — pick ONE of these three ways to get frames:
#
# Option A: ESP32-CAM (wireless, mounts on a moving robot)
ESP32CAM_IP = ""           # e.g. "192.168.1.62" — leave blank to skip this option
ESP32CAM_STREAM_PATH = "/stream"
#
# Option B: USB webcam plugged into THIS computer (fixed position — good
# for watching one greenhouse row from a stationary spot, not for a
# moving robot, since the webcam has to stay plugged into a computer)
USE_USB_WEBCAM = False     # set True to use this instead of ESP32-CAM
USB_WEBCAM_INDEX = 0       # 0 is usually the first/only webcam; try 1, 2... if wrong camera opens
#
# Option C: a saved photo file — used automatically if neither A nor B
# is configured above. Handy for testing the pipeline before any camera
# is actually connected.
TEST_IMAGE_PATH = "test_crop_photo.jpg"

BACKEND_URL = "http://localhost:4000"
ORDER_ID = "FRM-1234"      # <-- must match a real farming order id from your app
CHECK_INTERVAL_SECONDS = 15

logging.basicConfig(level=logging.INFO, format='%(asctime)s  %(message)s', datefmt='%H:%M:%S')
log = logging.getLogger("rover-crop-ai")

_webcam = None  # kept open between checks rather than reopened every time


def grab_frame():
    """Returns one OpenCV BGR frame, from whichever camera source is configured."""
    global _webcam

    if ESP32CAM_IP:
        url = f"http://{ESP32CAM_IP}{ESP32CAM_STREAM_PATH}"
        resp = requests.get(url, stream=True, timeout=5)
        bytes_data = b""
        for chunk in resp.iter_content(chunk_size=1024):
            bytes_data += chunk
            start = bytes_data.find(b'\xff\xd8')  # JPEG start marker
            end = bytes_data.find(b'\xff\xd9')    # JPEG end marker
            if start != -1 and end != -1:
                jpg = bytes_data[start:end + 2]
                arr = np.frombuffer(jpg, dtype=np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                if frame is not None:
                    return frame
        raise RuntimeError("Could not read a frame from the ESP32-CAM stream.")

    elif USE_USB_WEBCAM:
        if _webcam is None:
            _webcam = cv2.VideoCapture(USB_WEBCAM_INDEX)
            if not _webcam.isOpened():
                _webcam = None
                raise RuntimeError(
                    f"Could not open USB webcam at index {USB_WEBCAM_INDEX}. "
                    "Try USB_WEBCAM_INDEX = 1 (or 2) if you have more than one camera, "
                    "and make sure no other app (Zoom, Teams, etc.) is currently using it."
                )
        ok, frame = _webcam.read()
        if not ok or frame is None:
            raise RuntimeError("USB webcam opened but did not return a frame.")
        return frame

    else:
        frame = cv2.imread(TEST_IMAGE_PATH)
        if frame is None:
            raise RuntimeError(
                f"No camera configured, and couldn't find '{TEST_IMAGE_PATH}'. "
                "Set ESP32CAM_IP, or USE_USB_WEBCAM = True, or put a test photo at that path."
            )
        return frame


def post_reading(crop_id, status, confidence_pct, harvest_in_days):
    try:
        # /api/robot/crop-reading (not /api/crop-readings) — that other one
        # requires a logged-in browser session, which this script doesn't
        # have. This endpoint is the machine-to-machine equivalent, same
        # idea as how the ESP32 posts telemetry without logging in.
        resp = requests.post(
            f"{BACKEND_URL}/api/robot/crop-reading",
            json={
                "orderId": ORDER_ID,
                "cropId": crop_id,
                "status": status,
                "confidencePct": confidence_pct,
                "harvestInDays": harvest_in_days
            },
            timeout=5
        )
        if resp.status_code == 201:
            log.info(f"  -> posted: {crop_id} {status} ({confidence_pct}%)")
        else:
            log.warning(f"  -> backend rejected reading: {resp.status_code} {resp.text}")
    except requests.exceptions.RequestException as e:
        log.error(f"  -> could not reach backend at {BACKEND_URL}: {e}")


def get_crop_type_for_order(order_id):
    """
    Looks up which crop this farming order is actually growing, so the
    right color preset gets used. Falls back to the tomato default if
    the order doesn't have one set (e.g. it was created before this
    feature existed) or the backend can't be reached.
    """
    try:
        resp = requests.get(f"{BACKEND_URL}/api/robot/farming-order/{order_id}/crop-type", timeout=5)
        if resp.status_code == 200:
            return resp.json().get('cropType', 'tomato')
    except requests.exceptions.RequestException:
        pass
    return 'tomato'


def run_one_check():
    log.info("Grabbing frame and running detection...")
    try:
        frame = grab_frame()
    except RuntimeError as e:
        log.error(str(e))
        return

    crop_type = get_crop_type_for_order(ORDER_ID)
    detections = detect_crops(frame, crop_type=crop_type)
    log.info(f"Found {len(detections)} crop(s) in this frame (preset: {crop_type}).")

    for i, d in enumerate(detections):
        crop_id = f"{crop_type[:2].upper()}{i+1:03d}"  # e.g. TO001, PE001, BA001
        post_reading(crop_id, d['status'], d['confidencePct'], d['harvestInDays'])


if __name__ == '__main__':
    log.info(f"Starting ROVER-01 crop AI — checking every {CHECK_INTERVAL_SECONDS}s")
    if ESP32CAM_IP:
        camera_desc = f"ESP32-CAM at {ESP32CAM_IP}"
    elif USE_USB_WEBCAM:
        camera_desc = f"USB webcam (index {USB_WEBCAM_INDEX}) — TESTING MODE, not the final ESP32-CAM setup"
    else:
        camera_desc = f"TEST IMAGE ({TEST_IMAGE_PATH})"
    log.info(f"Camera: {camera_desc}")
    log.info(f"Posting readings to: {BACKEND_URL}/api/crop-readings for order {ORDER_ID}")

    while True:
        run_one_check()
        time.sleep(CHECK_INTERVAL_SECONDS)
