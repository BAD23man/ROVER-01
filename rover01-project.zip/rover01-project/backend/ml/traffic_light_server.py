"""
ROVER-01 — Traffic light inference bridge.

Same idea as inference_server.py (the crop AI): grabs frames from a
camera, runs detection, posts results to the Node backend. Kept as a
SEPARATE script from the crop one on purpose — they're different
features you may want running independently, and this one has a much
heavier install (see requirements-traffic-light.txt).

Run this on your own PC, not on the ESP32.

SETUP
------------------------------------------------------------------------
    pip install -r requirements-traffic-light.txt
    python traffic_light_server.py

Edit the CONFIG section below first.

WHAT THIS ACTUALLY DOES, HONESTLY
------------------------------------------------------------------------
Posts a stop/go/unknown recommendation to the admin dashboard, based on
real-time detection of a traffic light's current color. It does NOT
predict when the light will change — see traffic_light_detector.py's
docstring for why that's not something a camera can reliably do. Treat
this as an assistive indicator for a human watching the dashboard, not
an autonomous safety system.
"""

import time
import logging
import requests
import cv2
import numpy as np
from ultralytics import YOLO

from traffic_light_detector import detect_traffic_lights, recommend_action

# ---------------------------------------------------------------------------
# CONFIG — same three camera-source options as inference_server.py
# ---------------------------------------------------------------------------
ESP32CAM_IP = ""
ESP32CAM_STREAM_PATH = "/stream"

USE_USB_WEBCAM = False
USB_WEBCAM_INDEX = 0

TEST_IMAGE_PATH = "test_traffic_light.jpg"

BACKEND_URL = "http://localhost:4000"
CHECK_INTERVAL_SECONDS = 2   # faster than crop checks — a robot needs a timely answer, not a leisurely one

logging.basicConfig(level=logging.INFO, format='%(asctime)s  %(message)s', datefmt='%H:%M:%S')
log = logging.getLogger("rover-traffic-light")

_webcam = None


def grab_frame():
    """Same three-source logic as inference_server.py — see that file's comments."""
    global _webcam

    if ESP32CAM_IP:
        url = f"http://{ESP32CAM_IP}{ESP32CAM_STREAM_PATH}"
        resp = requests.get(url, stream=True, timeout=5)
        bytes_data = b""
        for chunk in resp.iter_content(chunk_size=1024):
            bytes_data += chunk
            start = bytes_data.find(b'\xff\xd8')
            end = bytes_data.find(b'\xff\xd9')
            if start != -1 and end != -1:
                jpg = bytes_data[start:end + 2]
                arr = np.frombuffer(jpg, dtype=np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                if frame is not None:
                    return frame
        raise RuntimeError("Could not read a frame from the ESP32-CAM stream.")

    elif USE_USB_WEBCAM:
        if _webcam is None:
            _webcam = cv2.VideoCapture(USB_WEBCAM_INDEX)
            if not _webcam.isOpened():
                _webcam = None
                raise RuntimeError(f"Could not open USB webcam at index {USB_WEBCAM_INDEX}.")
        ok, frame = _webcam.read()
        if not ok or frame is None:
            raise RuntimeError("USB webcam opened but did not return a frame.")
        return frame

    else:
        frame = cv2.imread(TEST_IMAGE_PATH)
        if frame is None:
            raise RuntimeError(
                f"No camera configured, and couldn't find '{TEST_IMAGE_PATH}'. "
                "Set ESP32CAM_IP, or USE_USB_WEBCAM = True, or put a test photo at that path."
            )
        return frame


def post_status(action, reason, detections):
    try:
        resp = requests.post(
            f"{BACKEND_URL}/api/robot/traffic-light",
            json={
                "action": action,
                "reason": reason,
                "detections": [{"state": d["state"], "confidence": d["colorConfidence"]} for d in detections]
            },
            timeout=5
        )
        if resp.status_code == 201:
            log.info(f"  -> posted: {action} ({reason})")
        else:
            log.warning(f"  -> backend rejected status: {resp.status_code} {resp.text}")
    except requests.exceptions.RequestException as e:
        log.error(f"  -> could not reach backend at {BACKEND_URL}: {e}")


if __name__ == '__main__':
    log.info(f"Starting ROVER-01 traffic light detector — checking every {CHECK_INTERVAL_SECONDS}s")
    log.info("Loading model (first run downloads ~5MB automatically)...")
    model = YOLO('yolo11n.pt')
    log.info("Model ready.")

    while True:
        try:
            frame = grab_frame()
            detections = detect_traffic_lights(frame, model)
            action, reason = recommend_action(detections)
            log.info(f"{action.upper():8s} — {reason} ({len(detections)} light(s) seen)")
            post_status(action, reason, detections)
        except RuntimeError as e:
            log.error(str(e))
        time.sleep(CHECK_INTERVAL_SECONDS)
