"""
ROVER-01 — Voice clip generator for the speaker feature.

Generates the two pre-recorded MP3 files the robot plays: a boot-up
welcome message, and a post-delivery thank-you (outdoor deliveries
only). Uses Google's free text-to-speech (no API key, no cost) — but
this needs real internet access to actually run, which is why it
wasn't runnable inside the sandboxed environment this was built in.
Run this on your own PC.

WHY PRE-RECORDED FILES INSTEAD OF LIVE SPEECH
------------------------------------------------------------------------
The ESP32 doesn't have the processing power for real-time text-to-
speech. The practical, cheap solution is a DFPlayer Mini module that
plays MP3 files off a microSD card — so your company name and exact
wording get "baked in" here, once, ahead of time. If you ever change
your company name, just re-run this script with the new text and
re-copy the files to the SD card — it's a 30-second fix, just not a
runtime code variable.

SETUP
------------------------------------------------------------------------
    pip install gTTS
    python3 generate_voice_clips.py

Then copy the two files it creates onto a microSD card, in a folder
named exactly "mp3", named exactly 0001.mp3 and 0002.mp3 (the DFPlayer
Mini's library expects this specific naming/folder convention).
"""

from gtts import gTTS
import os

# ---------------------------------------------------------------------------
# EDIT THESE — put your real company name and preferred wording in
# ---------------------------------------------------------------------------
COMPANY_NAME = "ROVER-01"  # <-- change this to your actual company/brand name

WELCOME_MESSAGE = "Welcome to ROVER-01 robot assistant."
THANK_YOU_MESSAGE = f"Thank you for trusting {COMPANY_NAME} for your delivery. We hope to serve you again soon."

# You can add more clips here later the same way — e.g. a "please stand
# back" caution message, or a "delivery failed, please help me" message
# for when the robot gets stuck (see the "more features" suggestions).
CLIPS = {
    "0001.mp3": WELCOME_MESSAGE,      # plays once, every time the robot powers on
    "0002.mp3": THANK_YOU_MESSAGE,    # plays after a successful outdoor delivery
}

if __name__ == '__main__':
    os.makedirs("mp3", exist_ok=True)
    for filename, text in CLIPS.items():
        path = os.path.join("mp3", filename)
        print(f"Generating {path} ...")
        print(f"  Text: \"{text}\"")
        try:
            tts = gTTS(text, lang='en')
            tts.save(path)
            print(f"  Saved.\n")
        except Exception as e:
            print(f"  FAILED: {e}")
            print("  (This needs real internet access to reach Google's TTS service.)\n")

    print("Done. Copy the 'mp3' folder onto your microSD card's root")
    print("directory (so the card contains: mp3/0001.mp3, mp3/0002.mp3),")
    print("then insert the card into the DFPlayer Mini module.")
