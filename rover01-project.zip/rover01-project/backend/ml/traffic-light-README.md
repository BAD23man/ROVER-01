# ROVER-01 Traffic Light Detection

An assistive indicator for the admin dashboard — genuinely working
computer vision, with one deliberate, honest limitation explained below.

## What this does

- Detects whether a traffic light is in view (real object detection,
  using a pretrained model — no training needed, "traffic light" is
  one of its 80 built-in categories)
- Reads the light's current color (red/yellow/green) using color
  analysis on the detected region
- Posts a simple **stop / go / unknown** recommendation to the admin
  dashboard, live, via a small indicator panel

## What this deliberately does NOT do

**It does not predict how much time is left before the light
changes.** That information only exists inside the traffic signal's
own controller — no camera-based system can reliably know it without
either the infrastructure itself broadcasting that data (rare, and not
something this robot's camera can access) or extremely long-term
statistical observation of one specific intersection across many
cycles (impractical for a robot that's usually just passing through
once). Any system claiming to show you a countdown timer from a camera
alone is either using infrastructure data you don't have, or guessing.

This is meant to be read by **a human watching the dashboard**, as one
more piece of information — not as an autonomous safety system. The
robot's actual obstacle avoidance (ultrasonic sensor) remains the real
safety mechanism.

## Setup — read this before installing

**This is a much heavier install than the crop AI.** Installing
`ultralytics` pulls in PyTorch, which alone is 500+ MB. During testing,
this filled up disk space on a machine with several GB free. Make sure
you have real disk space before running this.

```bash
cd ml
pip install -r requirements-traffic-light.txt
python3 traffic_light_detector.py
```

The self-test should show all three color-classification tests passing,
plus a confirmation that the model loads and runs.

## What was actually tested vs. what needs your confirmation

**Tested and confirmed working:**
- Color-classification logic — verified against synthetic crops with
  known red/yellow/green bulbs lit
- The full pipeline end-to-end — a simulated detection was posted to a
  real running backend, and confirmed to be correctly stored and
  retrievable afterward
- The model genuinely loads, runs, and has "traffic light" as a real
  detectable category

**NOT tested here, needs your own confirmation:**
- Real-world detection accuracy on an actual photo of a traffic light.
  This sandbox has no way to fetch real outdoor photos, and a
  hand-drawn synthetic scene correctly returned **zero** detections
  when tested (expected — the model needs real photographic texture,
  not drawn shapes). Test this yourself with a real photo, or point a
  webcam at a real traffic light (or even a photo of one on a screen),
  before trusting this for anything real.

## Running it for real

```bash
python3 traffic_light_server.py
```

Same three camera-source options as the crop AI's `inference_server.py`
(ESP32-CAM, USB webcam for testing, or a saved test photo) — edit the
CONFIG section at the top of the file.

## Speed, honestly

On a normal laptop CPU (no dedicated graphics card), expect roughly
2-5 checks per second — workable for a robot approaching an
intersection slowly, nowhere near the speed of dedicated hardware in
real self-driving systems.
