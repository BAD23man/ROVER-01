# ROVER-01 Crop AI

Real, working crop-ripeness detection — not simulated. This folder is
separate from the Node.js backend because it's Python (computer vision
needs different tools than a web server).

## What's actually real here

- `color_ripeness_detector.py` — a genuine, tested computer-vision
  detector using color analysis (no training data needed). Run it
  directly (`python3 color_ripeness_detector.py`) to see its self-test
  pass on a synthetic image with three fruit at different ripeness
  stages.
- `inference_server.py` — grabs frames from your ESP32-CAM (or a test
  photo), runs them through the detector, and posts real readings to
  your Node backend's `/api/robot/crop-reading` endpoint.
- `train_yolo.py` — the upgrade path to a real trained AI model, ready
  to use once you've collected and labeled your own crop photos.

This was tested end-to-end before being handed to you: a real photo was
analyzed, three tomatoes at different ripeness stages were correctly
detected, and those exact readings were confirmed sitting in the
backend's real storage afterward — not a mockup.

## Setup

```bash
cd ml
pip install -r requirements.txt
python3 color_ripeness_detector.py   # confirms the detector works on your machine
```

You should see:
```
Found 3 crop(s):
  Ripe         conf= 99.0%  harvest in 0 days  bbox=(...)
  Nearly ripe  conf= 99.0%  harvest in 3 days  bbox=(...)
  Unripe       conf= 99.0%  harvest in 10 days  bbox=(...)

Self-test PASSED — all three ripeness stages correctly detected.
```

## Running the real pipeline

1. Edit the CONFIG section at the top of `inference_server.py`:
   - `ESP32CAM_IP` — your camera's IP (leave blank to test with a photo
     file instead first)
   - `BACKEND_URL` — where your Node server is running
   - `ORDER_ID` — a real farming patrol order ID from your app (create
     one via `farming-order.html` first, then copy its ID from the URL)

2. Make sure your Node backend is running (`npm start` in `backend/`)

3. Run:
   ```bash
   python3 inference_server.py
   ```

4. **Important**: open `public/farming-tracking.html` and remove (or
   comment out) this line:
   ```js
   setInterval(simulateCropReading, 5000);
   ```
   Otherwise you'll see fake simulated readings mixed in alongside the
   real ones from this script — that line was only ever meant as a
   stand-in until this real pipeline existed.

## Testing with a USB webcam before your ESP32-CAM is ready

You don't need the ESP32-CAM wired up to start testing detection for
real. Plug any USB webcam into your PC and edit `inference_server.py`:

```python
ESP32CAM_IP = ""           # leave this blank
USE_USB_WEBCAM = True      # turn this on
USB_WEBCAM_INDEX = 0       # try 1 or 2 if the wrong camera opens
```

Point the webcam at some fruit/vegetables (even a photo of them on your
screen works for a quick test) and run `python3 inference_server.py` —
it'll grab live frames from your webcam every `CHECK_INTERVAL_SECONDS`
and run real detection on them, same as it would with the ESP32-CAM.

**This is for testing only** — a USB webcam has to stay plugged into a
computer, so it can't ride along on a moving delivery robot. For the
real robot, ESP32-CAM (wireless) is still the right choice; a USB
webcam only makes sense here for a stationary setup (e.g. permanently
watching one greenhouse row from a nearby PC) or for testing the AI
pipeline before your camera hardware exists at all.

Switch back to the ESP32-CAM later by setting `USE_USB_WEBCAM = False`
and filling in `ESP32CAM_IP` — nothing else in the pipeline changes.

## Multiple crops — not just tomatoes

`CROP_PRESETS` near the top of `color_ripeness_detector.py` has ready
presets for tomato, pepper, banana, mango, coffee, and strawberry —
each with its own hue ranges, since crops don't all ripen through the
same colors (bananas go green→yellow, never red; tomatoes go
green→orange→red). Whichever crop a farmer picks on the web form
(Step 3 of `farming-order.html`) is stored on the order and passed all
the way down into `detect_crops(frame, crop_type=...)` — you don't
need to touch this file for those six crops, it already works.

Growing something not in that list? Add your own preset to
`CROP_PRESETS` following the same pattern: point your camera at the
actual crop, take a test photo, and tune the hue ranges until
`detect_crops()` correctly separates ripe from unripe. Run
`python3 color_ripeness_detector.py` after any change — it includes a
guard that catches overlapping hue ranges between two ripeness stages,
which is a real, easy mistake to make and one that silently causes a
single fruit to get double-counted.

## Known limitations (read before relying on this)

- Color-only — no shape awareness. A red weed, tag, or piece of
  equipment in frame could register as a false detection. Aim the
  camera at crop rows specifically.
- No per-fruit tracking between checks — each photo is analyzed fresh,
  so a fruit isn't recognized as "the same one as last time," just
  re-detected. Fine for a general row overview, not for tracking one
  specific fruit's progress over weeks.
- Lighting-sensitive. Test in your actual greenhouse conditions, not
  just the synthetic test image.

## Voice announcements (speaker feature)

The robot can play pre-recorded voice clips through a small speaker —
"Welcome to ROVER-01 robot assistant" on every power-on, and a
"Thank you for trusting [Company Name]" message after a successful
outdoor delivery (RFID unlock approved by the backend).

**Important limitation:** the ESP32 can't do real-time text-to-speech
— it plays fixed MP3 files off a microSD card via a DFPlayer Mini
module. Generate those files with:

```bash
python3 generate_voice_clips.py
```

Edit `COMPANY_NAME` and the message text at the top of that script
first. This needs real internet access to reach Google's free
text-to-speech service — it could not be run inside the sandboxed
environment this was built in, so you're the one confirming it works.
Copy the two resulting files onto a microSD card as
`mp3/0001.mp3` and `mp3/0002.mp3`, insert it into the DFPlayer Mini,
and wire it up per the comments at the top of the ESP32 sketch.

Changing the company name later means re-running the script and
re-copying the files — not editing a code variable, since the words
are baked into the audio file itself.

## The upgrade path — Path B

Once color detection isn't accurate enough, `train_yolo.py` has the
full guide: collecting photos, labeling them for free with Roboflow,
training a real model on Google Colab's free GPU, and swapping it into
`inference_server.py` in place of the color-based detector — same
function signature, so nothing else in the pipeline needs to change.
This is genuinely a multi-week project on your end (mostly the data
collection and labeling), not something to start until the color-based
version has been running for a while and you know exactly where it
falls short.
