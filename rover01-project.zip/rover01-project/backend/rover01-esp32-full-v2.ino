/*
  ==========================================================================
  ROVER-01 — ESP32 4WD, FULL VERSION: motors + GPS + RFID + SPEAKER
  ==========================================================================

  This builds on rover01-esp32-connected.ino by adding GPS (real location),
  RFID (delivery-confirmation tap — now payment-gated, see below), and a
  speaker for voice announcements, all directly on this ONE ESP32 — no
  Raspberry Pi required. Camera is handled separately by a cheap
  ESP32-CAM board, which streams video directly to your browser.

  EXTRA LIBRARIES YOU NEED (Arduino IDE -> Library Manager):
    - "ArduinoJson" by Benoit Blanchon        (already needed before)
    - "TinyGPSPlus" by Mikal Hart              (parses the GPS module's data)
    - "MFRC522" by GithubCommunity             (drives the RFID reader)
    - "DFRobotDFPlayerMini" by DFRobot          (drives the speaker module)

  NEW WIRING IN THIS VERSION
  ------------------------------------------------------------------------
  NEO-6M GPS module
    TX   -> GPIO 16 (ESP32 RX2)
    RX   -> GPIO 17 (ESP32 TX2)
    VCC  -> 5V
    GND  -> common ground

  RC522 RFID reader (3.3V ONLY — do not power this from 5V)
    SDA/SS -> GPIO 2
    SCK    -> GPIO 14
    MOSI   -> GPIO 13
    MISO   -> GPIO 12
    RST    -> GPIO 4
    3.3V   -> ESP32 3V3 pin
    GND    -> common ground

  DFPlayer Mini speaker module
    RX   -> GPIO 33 (through a ~1k resistor)
    TX   -> GPIO 32
    VCC  -> 5V
    GND  -> common ground
    Speaker wires -> DFPlayer's SPK_1 / SPK_2 pins

  BEFORE UPLOADING: generate the two voice clip MP3 files using
  ml/generate_voice_clips.py, copy them onto a microSD card as
  mp3/0001.mp3 (welcome) and mp3/0002.mp3 (thank-you), and insert that
  card into the DFPlayer Mini.

  PAYMENT-GATED UNLOCK: the backend now rejects an RFID tap (HTTP 402)
  if the customer hasn't paid yet — this sketch only plays the
  thank-you message and marks the delivery complete if the backend
  actually approves the unlock (HTTP 200). A rejected tap logs to
  Serial but stays silent and doesn't mark anything delivered, so the
  customer can simply tap again after paying.

  Everything else (motors, ultrasonic, servo, WiFi, backend polling) is
  identical to rover01-esp32-connected.ino — fill in the same three
  settings below before uploading.
  ==========================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <ESP32Servo.h>
#include <TinyGPSPlus.h>
#include <SPI.h>
#include <MFRC522.h>
#include <DFRobotDFPlayerMini.h>   // Speaker — install via Library Manager, search "DFRobotDFPlayerMini"

// ---------------- USER SETTINGS ----------------
const char* AP_SSID       = "RobotCar";
const char* AP_PASSWORD   = "robot1234";

const char* HOME_WIFI_SSID     = "YOUR_HOME_WIFI_NAME";       // <-- fill this in
const char* HOME_WIFI_PASSWORD = "YOUR_HOME_WIFI_PASSWORD";   // <-- fill this in
const char* BACKEND_HOST       = "192.168.1.50";              // <-- your PC's IPv4 address
const int   BACKEND_PORT       = 4000;

// The order this robot is currently delivering. In a real multi-order
// setup, the backend would tell it which order to work on — for now,
// set this to whichever order you placed on the customer page.
String currentOrderId = "ORD-1042"; // <-- change to match a real order id

const int OBSTACLE_DISTANCE_CM = 20;

// ---------------- MOTOR PINS ----------------
const int IN1 = 5,  IN2 = 18;
const int IN3 = 19, IN4 = 21;
const int ENA = 22;
const int ENB = 23;

const bool SWAP_SIDES   = false;
const bool INVERT_LEFT  = false;
const bool INVERT_RIGHT = false;

const int TRIG_PIN  = 25;
const int ECHO_PIN  = 26;
const int SERVO_PIN = 27;
Servo scanServo;

// ---------------- GPS ----------------
TinyGPSPlus gps;
HardwareSerial GPSSerial(2); // Serial2 -> GPIO16 (RX2), GPIO17 (TX2)

// ---------------- RFID ----------------
const int RFID_SS_PIN  = 2;
const int RFID_RST_PIN = 4;
MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);

// ---------------- SPEAKER (DFPlayer Mini) ----------------
// Plays PRE-RECORDED voice clips from a microSD card — the ESP32 can't
// do real-time text-to-speech. Generate the two MP3 files first using
// ml/generate_voice_clips.py, then copy them to the SD card as
// mp3/0001.mp3 (welcome) and mp3/0002.mp3 (thank-you).
//
// Wiring:
//   DFPlayer RX -> ESP32 GPIO 33 (through a ~1k resistor, DFPlayer's RX
//                  is 3.3V-picky about a clean signal)
//   DFPlayer TX -> ESP32 GPIO 32
//   DFPlayer VCC -> 5V, GND -> common ground
//   Small speaker wired to DFPlayer's SPK_1/SPK_2 pins
HardwareSerial dfSerial(1);
DFRobotDFPlayerMini dfPlayer;
bool speakerReady = false;
unsigned long lastRfidCheck = 0;
bool orderAlreadyDelivered = false;

WebServer server(80);
bool autoMode      = false;
int  currentSpeed  = 700;
const int AUTO_SPEED = 600;
const int BACKUP_TIME_MS = 1200;
const int MAX_ESCAPE_ATTEMPTS = 4;

long lastFrontDistance = 999;

// ==========================================================================
// PWM
// ==========================================================================
const int PWM_FREQ = 5000;
const int PWM_RESOLUTION = 8;
void setupPWM() {
  ledcAttach(ENA, PWM_FREQ, PWM_RESOLUTION);
  ledcAttach(ENB, PWM_FREQ, PWM_RESOLUTION);
}
void pwmWrite(int pin, int value) { ledcWrite(pin, value); }

// ==========================================================================
// MOTOR CONTROL
// ==========================================================================
void setLeftMotorRaw(int speed, bool forward) {
  pwmWrite(ENA, speed);
  digitalWrite(IN1, forward ? HIGH : LOW);
  digitalWrite(IN2, forward ? LOW  : HIGH);
}
void setRightMotorRaw(int speed, bool forward) {
  pwmWrite(ENB, speed);
  digitalWrite(IN3, forward ? HIGH : LOW);
  digitalWrite(IN4, forward ? LOW  : HIGH);
}
void setLeftMotor(int speed, bool forward) {
  bool f = forward != INVERT_LEFT;
  if (SWAP_SIDES) setRightMotorRaw(speed, f); else setLeftMotorRaw(speed, f);
}
void setRightMotor(int speed, bool forward) {
  bool f = forward != INVERT_RIGHT;
  if (SWAP_SIDES) setLeftMotorRaw(speed, f); else setRightMotorRaw(speed, f);
}
void stopMotors() {
  pwmWrite(ENA, 0); pwmWrite(ENB, 0);
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
}
void moveForward(int s)  { setLeftMotor(s, true);  setRightMotor(s, true);  }
void moveBackward(int s) { setLeftMotor(s, false); setRightMotor(s, false); }
void turnLeft(int s)     { setLeftMotor(s, false); setRightMotor(s, true);  }
void turnRight(int s)    { setLeftMotor(s, true);  setRightMotor(s, false); }

void applyCommand(const String& action) {
  if (autoMode) return;
  if (action == "forward")       moveForward(currentSpeed);
  else if (action == "backward") moveBackward(currentSpeed);
  else if (action == "left")     turnLeft(currentSpeed);
  else if (action == "right")    turnRight(currentSpeed);
  else if (action == "stop")     stopMotors();
}

// ==========================================================================
// ULTRASONIC + OBSTACLE AVOIDANCE (unchanged)
// ==========================================================================
long readDistanceRaw() {
  digitalWrite(TRIG_PIN, LOW); delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return 999;
  return duration * 0.034 / 2;
}
long readDistanceCM() {
  long a = readDistanceRaw(); delay(15);
  long b = readDistanceRaw(); delay(15);
  long c = readDistanceRaw();
  if (a > b) { long t=a; a=b; b=t; }
  if (b > c) { long t=b; b=c; c=t; }
  if (a > b) { long t=a; a=b; b=t; }
  return b;
}

long distAngle[5];
const int scanAngles[5] = {160, 125, 90, 55, 20};
void sweepAndRead() {
  for (int i = 0; i < 5; i++) {
    scanServo.write(scanAngles[i]);
    delay(i == 0 ? 300 : 180);
    distAngle[i] = readDistanceCM();
  }
  scanServo.write(90); delay(150);
}
int pickBestIndex() {
  int bestIndex = 2;
  for (int i = 0; i < 5; i++) {
    if (distAngle[i] > distAngle[bestIndex]) bestIndex = i;
    else if (distAngle[i] == distAngle[bestIndex] && abs(i-2) < abs(bestIndex-2)) bestIndex = i;
  }
  return bestIndex;
}
void steerToward(int bestIndex) {
  if (bestIndex == 2) { moveForward(AUTO_SPEED); delay(300); }
  else if (bestIndex < 2) { turnLeft(AUTO_SPEED); delay(300 + (2-bestIndex)*120); }
  else { turnRight(AUTO_SPEED); delay(300 + (bestIndex-2)*120); }
  stopMotors();
}
void obstacleAvoid() {
  long distFront = readDistanceCM();
  lastFrontDistance = distFront;
  if (distFront > OBSTACLE_DISTANCE_CM) { moveForward(AUTO_SPEED); return; }
  stopMotors(); delay(80);
  for (int attempt = 0; attempt < MAX_ESCAPE_ATTEMPTS; attempt++) {
    sweepAndRead();
    int bestIndex = pickBestIndex();
    if (distAngle[bestIndex] > OBSTACLE_DISTANCE_CM) { steerToward(bestIndex); return; }
    moveBackward(AUTO_SPEED); delay(BACKUP_TIME_MS); stopMotors(); delay(300);
    sweepAndRead();
    bestIndex = pickBestIndex();
    if (distAngle[bestIndex] > OBSTACLE_DISTANCE_CM) { steerToward(bestIndex); return; }
  }
  turnRight(AUTO_SPEED); delay(500); stopMotors();
}

// ==========================================================================
// GPS — read whatever the module has, non-blocking
// ==========================================================================
void pumpGPS() {
  while (GPSSerial.available() > 0) {
    gps.encode(GPSSerial.read());
  }
}

// ==========================================================================
// RFID — check for a card tap, report it to the backend once
// ==========================================================================
unsigned long lastRfidAttemptTime = 0;
const unsigned long RFID_RETRY_COOLDOWN_MS = 3000; // avoid hammering the backend if a card sits on the reader

void checkRFID() {
  if (orderAlreadyDelivered) return; // already succeeded, don't spam it
  if (millis() - lastRfidAttemptTime < RFID_RETRY_COOLDOWN_MS) return;
  if (!rfid.PICC_IsNewCardPresent()) return;
  if (!rfid.PICC_ReadCardSerial()) return;
  lastRfidAttemptTime = millis();

  String cardId = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    cardId += String(rfid.uid.uidByte[i], HEX);
  }
  Serial.print("RFID card detected: "); Serial.println(cardId);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    String url = String("http://") + BACKEND_HOST + ":" + BACKEND_PORT + "/api/robot/rfid";
    http.begin(url);
    http.addHeader("Content-Type", "application/json");
    String payload = String("{\"orderId\":\"") + currentOrderId + "\",\"cardId\":\"" + cardId + "\"}";
    int code = http.POST(payload);
    Serial.print("RFID reported to backend, response code: "); Serial.println(code);
    http.end();

    if (code == 200) {
      // Backend confirmed: payment was completed, delivery is genuine.
      orderAlreadyDelivered = true;
      Serial.println("Unlock approved — playing thank-you message.");
      if (speakerReady) dfPlayer.play(2); // mp3/0002.mp3 — the thank-you message
      // This is also where you'd trigger the actual compartment lock's
      // release (servo/solenoid) — not wired in yet in this sketch.
    } else if (code == 402) {
      // Backend rejected: payment hasn't been completed yet. Don't mark
      // delivered — the customer can tap again once they've paid.
      Serial.println("Unlock REJECTED — payment not completed yet.");
    } else {
      Serial.print("Unlock request failed or order not found, code: "); Serial.println(code);
    }
  }

  rfid.PICC_HaltA();
}

// ==========================================================================
// BACKEND POLLING
// ==========================================================================
unsigned long lastPollTime = 0;
unsigned long lastTelemetryTime = 0;
const unsigned long POLL_INTERVAL_MS = 300;
const unsigned long TELEMETRY_INTERVAL_MS = 2000;

void pollBackend() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = String("http://") + BACKEND_HOST + ":" + BACKEND_PORT + "/api/robot/poll";
  http.begin(url);
  http.setTimeout(1000);
  int code = http.GET();

  if (code == 200) {
    String body = http.getString();
    StaticJsonDocument<256> doc;
    if (deserializeJson(doc, body) == DeserializationError::Ok) {
      bool wantsAuto = doc["mode"]["auto"] | false;
      String action = doc["command"]["action"] | "stop";
      autoMode = wantsAuto;
      if (!autoMode) applyCommand(action);
    }
  }
  http.end();
}

void postTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = String("http://") + BACKEND_HOST + ":" + BACKEND_PORT + "/api/robot/telemetry";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");

  String payload;
  if (gps.location.isValid() && gps.location.age() < 5000) {
    // Real GPS fix available — send real coordinates
    payload = String("{\"orderId\":\"") + currentOrderId + "\""
             + ",\"lat\":" + String(gps.location.lat(), 6)
             + ",\"lng\":" + String(gps.location.lng(), 6)
             + ",\"gpsSats\":" + gps.satellites.value()
             + ",\"battery\":100"
             + ",\"distanceCm\":" + lastFrontDistance + "}";
  } else {
    // No GPS fix yet (common indoors, or right after power-on) — still
    // report battery/distance so the admin log shows the robot is alive.
    payload = String("{\"battery\":100,\"distanceCm\":") + lastFrontDistance + "}";
  }

  http.POST(payload);
  http.end();
}

// ==========================================================================
// LOCAL WEB PAGES (backup control)
// ==========================================================================
void handleRoot() {
  server.send(200, "text/html",
    "<h2>ROVER-01 local backup control</h2>"
    "<p>Use the admin dashboard on your computer for full control.</p>"
    "<button onclick=\"fetch('/cmd?action=forward')\">Forward</button> "
    "<button onclick=\"fetch('/cmd?action=backward')\">Backward</button> "
    "<button onclick=\"fetch('/cmd?action=left')\">Left</button> "
    "<button onclick=\"fetch('/cmd?action=right')\">Right</button> "
    "<button onclick=\"fetch('/cmd?action=stop')\">Stop</button>");
}
void handleCmd() {
  applyCommand(server.arg("action"));
  server.send(200, "text/plain", "OK");
}
void handleMode() {
  if (server.hasArg("auto")) { autoMode = server.arg("auto") == "1"; stopMotors(); }
  server.send(200, "text/plain", "OK");
}

// ==========================================================================
// SETUP
// ==========================================================================
void setup() {
  Serial.begin(115200);

  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  setupPWM();
  stopMotors();

  // GPS on Serial2 (GPIO16=RX, GPIO17=TX), NEO-6M's default baud rate
  GPSSerial.begin(9600, SERIAL_8N1, 16, 17);

  // RFID over SPI on custom pins
  SPI.begin(14, 12, 13, 2); // SCK, MISO, MOSI, SS
  rfid.PCD_Init();
  Serial.println("RFID reader initialized.");

  // Speaker — plays the boot-up welcome message once initialized.
  // If this fails (no module wired in, or SD card missing), the robot
  // still works fine — it just stays silent, doesn't block anything.
  dfSerial.begin(9600, SERIAL_8N1, 32, 33);
  if (dfPlayer.begin(dfSerial)) {
    speakerReady = true;
    dfPlayer.volume(22); // 0-30, tune to your speaker
    dfPlayer.play(1);    // mp3/0001.mp3 — the welcome message
    Serial.println("Speaker ready — playing welcome message.");
  } else {
    Serial.println("Speaker not detected (check wiring/SD card) — continuing without it.");
  }

  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  Serial.print("Backup hotspot started: "); Serial.println(AP_SSID);

  Serial.print("Connecting to home WiFi: "); Serial.println(HOME_WIFI_SSID);
  WiFi.begin(HOME_WIFI_SSID, HOME_WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(300);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.print("Connected. ESP32 IP: "); Serial.println(WiFi.localIP());
  } else {
    Serial.println();
    Serial.println("Could NOT connect to home WiFi — check SSID/password.");
  }

  server.on("/", handleRoot);
  server.on("/cmd", handleCmd);
  server.on("/mode", handleMode);
  server.begin();

  scanServo.attach(SERVO_PIN);
  scanServo.write(90);
  delay(300);
}

// ==========================================================================
// LOOP
// ==========================================================================
void loop() {
  server.handleClient();
  pumpGPS();
  checkRFID();

  unsigned long now = millis();
  if (now - lastPollTime >= POLL_INTERVAL_MS) {
    lastPollTime = now;
    pollBackend();
  }
  if (now - lastTelemetryTime >= TELEMETRY_INTERVAL_MS) {
    lastTelemetryTime = now;
    postTelemetry();
  }

  if (autoMode) {
    obstacleAvoid();
  }
}
