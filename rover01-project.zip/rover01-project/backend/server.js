// ROVER-01 Backend — connects the robot, the admin dashboard, and the customer
// tracking page. Run with `npm start`. See README.md for full setup.

const express = require('express');
const http = require('http');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const { Server } = require('socket.io');

const app = express();
app.use(cors());
app.use(express.json());
app.use(session({
  secret: 'rover01-dev-secret-change-this-for-real-deployments',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 8 } // 8 hour login session
}));

// Serve the dashboards, login pages, etc. from ./public — this is what
// makes everything reachable at http://localhost:4000 with ONE server.
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// ---------------------------------------------------------------------------
// USERS — same lightweight JSON-file approach as orders, just for accounts.
// Passwords are hashed with bcrypt, never stored in plain text.
// ---------------------------------------------------------------------------
const USERS_FILE = path.join(__dirname, 'users.json');
function loadUsers() {
  if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(USERS_FILE));
}
function saveUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}
let users = loadUsers();

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
  next();
}

// ---------------------------------------------------------------------------
// SIMPLE JSON "DATABASE" — swap this for MongoDB/Postgres when you go to
// production. Good enough to develop against right now.
// ---------------------------------------------------------------------------
const DB_FILE = path.join(__dirname, 'orders.json');

function seedOrders() {
  return [
    {
      id: 'ORD-1042', customer: 'Amina N.', phone: '+250700000001',
      address: '14 KG 7 Ave, Kigali', status: 'enroute',
      pos: { lat: -1.9553, lng: 30.0912 },   // starting point (e.g. warehouse)
      dest: { lat: -1.9441, lng: 30.0619 },  // customer's address
      createdAt: Date.now()
    },
    {
      id: 'ORD-1043', customer: 'Eric M.', phone: '+250700000002',
      address: 'Plot 22, Nyarugenge', status: 'queued',
      pos: { lat: -1.9500, lng: 30.0588 },
      dest: { lat: -1.9536, lng: 30.0655 },
      createdAt: Date.now()
    }
  ];
}
function loadOrders() {
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify(seedOrders(), null, 2));
  return JSON.parse(fs.readFileSync(DB_FILE));
}
function saveOrders(orders) {
  fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
}
let orders = loadOrders();

// ---------------------------------------------------------------------------
// INDOOR DELIVERY — blueprints (floor plan images) + indoor orders
// (a customer-drawn path across that floor plan). Same lightweight
// JSON-file pattern as orders/users.
// ---------------------------------------------------------------------------
const BLUEPRINTS_FILE = path.join(__dirname, 'blueprints.json');
const INDOOR_ORDERS_FILE = path.join(__dirname, 'indoor-orders.json');

function loadBlueprints() {
  if (!fs.existsSync(BLUEPRINTS_FILE)) fs.writeFileSync(BLUEPRINTS_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(BLUEPRINTS_FILE));
}
function saveBlueprints(list) {
  fs.writeFileSync(BLUEPRINTS_FILE, JSON.stringify(list, null, 2));
}
let blueprints = loadBlueprints();

function loadIndoorOrders() {
  if (!fs.existsSync(INDOOR_ORDERS_FILE)) fs.writeFileSync(INDOOR_ORDERS_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(INDOOR_ORDERS_FILE));
}
function saveIndoorOrders(list) {
  fs.writeFileSync(INDOOR_ORDERS_FILE, JSON.stringify(list, null, 2));
}
let indoorOrders = loadIndoorOrders();

// ---------------------------------------------------------------------------
// FARMING — a greenhouse "blueprint" + a route the robot patrols on a
// schedule, checking crops as it goes. Same storage pattern as indoor
// orders, plus a schedule and a running log of crop readings.
// ---------------------------------------------------------------------------
const FARMING_ORDERS_FILE = path.join(__dirname, 'farming-orders.json');
const CROP_READINGS_FILE = path.join(__dirname, 'crop-readings.json');

function loadFarmingOrders() {
  if (!fs.existsSync(FARMING_ORDERS_FILE)) fs.writeFileSync(FARMING_ORDERS_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(FARMING_ORDERS_FILE));
}
function saveFarmingOrders(list) {
  fs.writeFileSync(FARMING_ORDERS_FILE, JSON.stringify(list, null, 2));
}
let farmingOrders = loadFarmingOrders();

function loadCropReadings() {
  if (!fs.existsSync(CROP_READINGS_FILE)) fs.writeFileSync(CROP_READINGS_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(CROP_READINGS_FILE));
}
function saveCropReadings(list) {
  fs.writeFileSync(CROP_READINGS_FILE, JSON.stringify(list, null, 2));
}
let cropReadings = loadCropReadings();

// ---------------------------------------------------------------------------
// CHAT — simple per-order message thread between a customer and admin.
// ---------------------------------------------------------------------------
const CHAT_FILE = path.join(__dirname, 'chat-messages.json');
function loadChat() {
  if (!fs.existsSync(CHAT_FILE)) fs.writeFileSync(CHAT_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(CHAT_FILE));
}
function saveChat(list) { fs.writeFileSync(CHAT_FILE, JSON.stringify(list, null, 2)); }
let chatMessages = loadChat();

// ---------------------------------------------------------------------------
// FLEET — a simple robot registry. Only one robot exists today, but every
// telemetry event now tags a robotId, so the admin dashboard's Fleet
// panel is ready the moment a second robot starts reporting in.
// ---------------------------------------------------------------------------
const ROBOTS_FILE = path.join(__dirname, 'robots.json');
function loadRobots() {
  if (!fs.existsSync(ROBOTS_FILE)) {
    fs.writeFileSync(ROBOTS_FILE, JSON.stringify([{ id: 'ROVER-01', name: 'Rover 01', status: 'idle', battery: null, lastSeen: null }], null, 2));
  }
  return JSON.parse(fs.readFileSync(ROBOTS_FILE));
}
function saveRobots(list) { fs.writeFileSync(ROBOTS_FILE, JSON.stringify(list, null, 2)); }
let robots = loadRobots();

// ---------------------------------------------------------------------------
// BATTERY HISTORY — a lightweight log of battery % over time, purely for
// the analytics dashboard's battery chart. Capped so the file can't grow
// forever.
// ---------------------------------------------------------------------------
const BATTERY_LOG_FILE = path.join(__dirname, 'battery-log.json');
function loadBatteryLog() {
  if (!fs.existsSync(BATTERY_LOG_FILE)) fs.writeFileSync(BATTERY_LOG_FILE, JSON.stringify([], null, 2));
  return JSON.parse(fs.readFileSync(BATTERY_LOG_FILE));
}
function saveBatteryLog(list) { fs.writeFileSync(BATTERY_LOG_FILE, JSON.stringify(list, null, 2)); }
let batteryLog = loadBatteryLog();
function logBattery(battery) {
  if (battery == null) return;
  batteryLog.push({ battery, timestamp: Date.now() });
  if (batteryLog.length > 500) batteryLog = batteryLog.slice(-500);
  saveBatteryLog(batteryLog);
}

// ---------------------------------------------------------------------------
// ROBOT STATE FOR PLAIN-HTTP POLLING
// The ESP32 can't easily speak the Socket.IO protocol, so it polls this
// over plain HTTP instead. The admin dashboard still uses Socket.IO — this
// just mirrors the latest command/mode so a simple HTTPClient GET works too.
// ---------------------------------------------------------------------------
let robotState = {
  command: { action: 'stop' },
  mode: { auto: false }
};

// ---------------------------------------------------------------------------
// INDOOR ROBOT CONTROL — deliberately SEPARATE from robotState above.
// Admin only ever controls the outdoor robot; indoor joystick commands
// come from the CUSTOMER who placed that specific indoor order, from
// indoor-tracking.html. Keyed by order id so multiple indoor orders
// don't cross-control each other.
// ---------------------------------------------------------------------------
let indoorRobotState = {}; // { [orderId]: { action: 'stop' } }

function getIndoorState(orderId) {
  if (!indoorRobotState[orderId]) indoorRobotState[orderId] = { action: 'stop' };
  return indoorRobotState[orderId];
}

function findOrder(id) { return orders.find(o => o.id === id); }

// Real-world distance between two {lat, lng} points, in kilometers.
// This is the standard haversine formula — accurate for GPS coordinates.
function distanceKm(a, b) {
  const R = 6371; // Earth's radius in km
  const dLat = (b.lat - a.lat) * Math.PI / 180;
  const dLng = (b.lng - a.lng) * Math.PI / 180;
  const lat1 = a.lat * Math.PI / 180;
  const lat2 = b.lat * Math.PI / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

// ---------------------------------------------------------------------------
// SMS — stubbed for now (just logs). Swap the body of this function for a
// real provider, e.g.:
//   twilioClient.messages.create({ to: phone, from: TWILIO_NUMBER, body: message })
// ---------------------------------------------------------------------------
function sendSMS(phone, message) {
  console.log(`[SMS -> ${phone}] ${message}`);
}

// ---------------------------------------------------------------------------
// REST API
// ---------------------------------------------------------------------------
app.get('/api/orders', (req, res) => res.json(orders));

app.get('/api/orders/:id', (req, res) => {
  const o = findOrder(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  res.json(o);
});

app.post('/api/orders', (req, res) => {
  const o = {
    id: 'ORD-' + Math.floor(1000 + Math.random() * 9000),
    status: 'queued',
    createdAt: Date.now(),
    ...req.body
  };
  orders.push(o);
  saveOrders(orders);
  io.to('admin').emit('order:new', o);
  res.status(201).json(o);
});

app.get('/health', (req, res) => res.json({ ok: true, orders: orders.length }));

// ---------------------------------------------------------------------------
// INDOOR DELIVERY — upload a floor plan, draw a path on it, place an order
// ---------------------------------------------------------------------------

// List all blueprints (any logged-in user can browse and pick one)
app.get('/api/blueprints', requireLogin, (req, res) => res.json(blueprints));

// Upload a new blueprint image. `dataUrl` is a base64 data URI
// (e.g. "data:image/png;base64,...") — the browser converts the file to
// this before sending, no separate file-upload library needed.
app.post('/api/blueprints', requireLogin, (req, res) => {
  const { name, dataUrl } = req.body;
  if (!name || !dataUrl) return res.status(400).json({ error: 'Name and image are required.' });
  const bp = {
    id: 'BP-' + Math.floor(1000 + Math.random() * 9000),
    name,
    dataUrl,
    uploadedBy: req.session.user.id,
    createdAt: Date.now()
  };
  blueprints.push(bp);
  saveBlueprints(blueprints);
  res.status(201).json(bp);
});

// Place an indoor order: a blueprint + an ordered list of waypoints
// (pixel coordinates on that image) the customer drew, from start to stop.
app.post('/api/indoor-orders', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only' });
  const { blueprintId, waypoints, label, priority } = req.body;
  if (!blueprintId || !Array.isArray(waypoints) || waypoints.length < 2) {
    return res.status(400).json({ error: 'Please draw a path with at least a start and stop point.' });
  }
  const o = {
    id: 'IND-' + Math.floor(1000 + Math.random() * 9000),
    customerId: req.session.user.id,
    customer: req.session.user.fullName,
    blueprintId,
    waypoints,
    label: label || 'Indoor delivery',
    status: 'queued',
    priority: !!priority,
    currentWaypointIndex: 0,
    createdAt: Date.now()
  };
  indoorOrders.push(o);
  saveIndoorOrders(indoorOrders);
  io.to('admin').emit('indoor-order:new', o);
  res.status(201).json(o);
});

app.get('/api/indoor-orders', requireLogin, (req, res) => res.json(indoorOrders));

// The logged-in customer's current active indoor order, if any.
app.get('/api/indoor-orders/mine', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only' });
  const active = indoorOrders.find(o => o.customerId === req.session.user.id && o.status !== 'delivered');
  res.json(active || null);
});

app.get('/api/indoor-orders/:id', requireLogin, (req, res) => {
  const o = indoorOrders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  res.json(o);
});

// ---------------------------------------------------------------------------
// FARMING endpoints
// ---------------------------------------------------------------------------

// Place a farming patrol: a greenhouse blueprint + a route + a schedule
// for when the robot should start its checking rounds.
const VALID_CROP_TYPES = ['tomato', 'pepper', 'banana', 'mango', 'coffee', 'strawberry', 'other'];

app.post('/api/farming-orders', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only' });
  const { blueprintId, waypoints, label, schedule, cropType } = req.body;
  if (!blueprintId || !Array.isArray(waypoints) || waypoints.length < 2) {
    return res.status(400).json({ error: 'Please draw a route through your greenhouse first.' });
  }
  if (!schedule || !schedule.frequency) {
    return res.status(400).json({ error: 'Please choose when the robot should check your crops.' });
  }
  const o = {
    id: 'FRM-' + Math.floor(1000 + Math.random() * 9000),
    customerId: req.session.user.id,
    customer: req.session.user.fullName,
    blueprintId,
    waypoints,
    label: label || 'Greenhouse patrol',
    cropType: VALID_CROP_TYPES.includes(cropType) ? cropType : 'other',
    schedule, // { frequency: 'once'|'daily'|'hourly', startTime: 'HH:MM' }
    status: 'scheduled',
    createdAt: Date.now()
  };
  farmingOrders.push(o);
  saveFarmingOrders(farmingOrders);
  io.to('admin').emit('farming-order:new', o);
  res.status(201).json(o);
});

app.get('/api/farming-orders', requireLogin, (req, res) => res.json(farmingOrders));

app.get('/api/farming-orders/mine', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only' });
  const active = farmingOrders.find(o => o.customerId === req.session.user.id);
  res.json(active || null);
});

app.get('/api/farming-orders/:id', requireLogin, (req, res) => {
  const o = farmingOrders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  res.json(o);
});

// Machine-facing, unauthenticated — same reasoning as /api/robot/telemetry
// and /api/robot/crop-reading. Deliberately returns ONLY the crop type,
// not the full order (customer name, waypoints, etc. stay private).
app.get('/api/robot/farming-order/:id/crop-type', (req, res) => {
  const o = farmingOrders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  res.json({ cropType: o.cropType || 'tomato' });
});

// Crop readings — a running log of what the camera/AI model found.
function insertCropReading({ orderId, cropId, status, confidencePct, harvestInDays }) {
  const reading = {
    id: 'CR-' + Math.floor(100000 + Math.random() * 899999),
    orderId, cropId, status, confidencePct, harvestInDays,
    timestamp: Date.now()
  };
  cropReadings.push(reading);
  saveCropReadings(cropReadings);
  io.to('order:' + orderId).emit('crop-reading', reading);
  io.to('admin').emit('log', { message: `Crop reading (${orderId}): ${cropId} — ${status} (${confidencePct}%)`, level: '' });
  return reading;
}

// Used by the browser (logged-in customer/admin session).
app.post('/api/crop-readings', requireLogin, (req, res) => {
  const { orderId, cropId } = req.body;
  if (!orderId || !cropId) return res.status(400).json({ error: 'orderId and cropId are required.' });
  res.status(201).json(insertCropReading(req.body));
});

// Used by the AI inference script (ml/inference_server.py) — no browser
// session exists there, same reasoning as /api/robot/telemetry being
// unauthenticated. Anyone who can reach your server on the network can
// call this, same trust model as the rest of the robot-facing endpoints
// — fine on your home network, worth locking down before any public
// deployment (see README).
app.post('/api/robot/crop-reading', (req, res) => {
  const { orderId, cropId } = req.body;
  if (!orderId || !cropId) return res.status(400).json({ error: 'orderId and cropId are required.' });
  res.status(201).json(insertCropReading(req.body));
});

app.get('/api/crop-readings/:orderId', requireLogin, (req, res) => {
  res.json(cropReadings.filter(r => r.orderId === req.params.orderId).slice(-50));
});

// ---------------------------------------------------------------------------
// TRAFFIC LIGHT — assistive indicator only, not an autonomous safety
// system (see ml/traffic_light_detector.py for why timing predictions
// aren't included at all). Latest status is kept in memory (not saved
// to disk — no real value in a permanent history of past light states)
// and pushed live to the admin dashboard.
// ---------------------------------------------------------------------------
let latestTrafficLightStatus = { action: 'unknown', reason: 'No data yet', detections: [], timestamp: null };

app.post('/api/robot/traffic-light', (req, res) => {
  const { action, reason, detections } = req.body;
  if (!action) return res.status(400).json({ error: 'action is required.' });
  latestTrafficLightStatus = { action, reason: reason || '', detections: detections || [], timestamp: Date.now() };
  io.to('admin').emit('traffic-light:update', latestTrafficLightStatus);
  res.status(201).json({ ok: true });
});

app.get('/api/robot/traffic-light', requireLogin, (req, res) => res.json(latestTrafficLightStatus));


// ---------------------------------------------------------------------------
// Helper: find any order type by id, regardless of collection. Used by
// several of the features below (rating, photo, priority, chat, payment)
// since a customer's order could be in orders/indoorOrders/farmingOrders.
// ---------------------------------------------------------------------------
function findAnyOrder(id) {
  return orders.find(o => o.id === id) || indoorOrders.find(o => o.id === id) || farmingOrders.find(o => o.id === id);
}
function saveWhicheverList(order) {
  if (orders.includes(order)) saveOrders(orders);
  else if (indoorOrders.includes(order)) saveIndoorOrders(indoorOrders);
  else if (farmingOrders.includes(order)) saveFarmingOrders(farmingOrders);
}

// ---- STAR RATING + FEEDBACK ----
app.post('/api/orders/:id/rate', requireLogin, (req, res) => {
  const o = findAnyOrder(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  if (o.customerId !== req.session.user.id) return res.status(403).json({ error: 'Not your order' });
  const { rating, feedback } = req.body;
  if (!rating || rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be 1-5.' });
  o.rating = rating;
  o.feedback = feedback || '';
  saveWhicheverList(o);
  io.to('admin').emit('log', { message: `Rated ${o.id}: ${rating}★ — "${feedback || ''}"`, level: '' });
  res.json({ ok: true });
});

// ---- ORDER HISTORY ----
// Returns every order (any status) belonging to the logged-in customer,
// across whichever collection matches their account type.
app.get('/api/orders/history', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only' });
  const uid = req.session.user.id;
  const all = [
    ...orders.filter(o => o.customerId === uid).map(o => ({ ...o, kind: 'outdoor' })),
    ...indoorOrders.filter(o => o.customerId === uid).map(o => ({ ...o, kind: 'indoor' })),
    ...farmingOrders.filter(o => o.customerId === uid).map(o => ({ ...o, kind: 'farming' }))
  ];
  all.sort((a, b) => b.createdAt - a.createdAt);
  res.json(all);
});

// ---- DELIVERY PROOF PHOTO ----
// Settable by an admin right now (dashboard has an upload button). Once
// a real ESP32-CAM snapshot-on-delivery is wired in, that would call
// this same endpoint instead.
app.post('/api/orders/:id/delivery-photo', requireLogin, (req, res) => {
  if (req.session.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  const o = findAnyOrder(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  const { dataUrl } = req.body;
  if (!dataUrl) return res.status(400).json({ error: 'No image provided.' });
  o.deliveryPhotoUrl = dataUrl;
  saveWhicheverList(o);
  io.to('order:' + o.id).emit('order:update', o);
  res.json({ ok: true });
});

// ---- STAT / PRIORITY FLAG ----
app.post('/api/orders/:id/priority', requireLogin, (req, res) => {
  const o = findAnyOrder(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  if (o.customerId !== req.session.user.id) return res.status(403).json({ error: 'Not your order' });
  o.priority = !!req.body.priority;
  saveWhicheverList(o);
  io.to('admin').emit('log', { message: `${o.priority ? '🔴 STAT flagged' : 'Priority cleared'}: ${o.id}`, level: o.priority ? 'crit' : '' });
  io.to('admin').emit('order:priority-changed', o);
  res.json({ ok: true });
});

// ---- CHAT ----
app.get('/api/chat/:orderId', requireLogin, (req, res) => {
  res.json(chatMessages.filter(m => m.orderId === req.params.orderId).slice(-100));
});

// ---- FLEET ----
app.get('/api/robots', requireLogin, (req, res) => res.json(robots));

// ---- ANALYTICS (admin only) ----
app.get('/api/analytics/summary', requireLogin, (req, res) => {
  if (req.session.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });

  // Deliveries per day, last 7 days
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    days.push(d.toISOString().slice(0, 10));
  }
  const allDelivered = [...orders, ...indoorOrders, ...farmingOrders].filter(o => o.status === 'delivered' && o.deliveredAt);
  const perDay = days.map(day => ({
    day,
    count: allDelivered.filter(o => new Date(o.deliveredAt).toISOString().slice(0, 10) === day).length
  }));

  // Average delivery time (createdAt -> deliveredAt), outdoor orders only
  // (the ones with a real time-based journey)
  const withDuration = orders.filter(o => o.status === 'delivered' && o.deliveredAt && o.createdAt);
  const avgDeliveryMinutes = withDuration.length
    ? Math.round(withDuration.reduce((sum, o) => sum + (o.deliveredAt - o.createdAt), 0) / withDuration.length / 60000)
    : null;

  // Average rating
  const rated = [...orders, ...indoorOrders, ...farmingOrders].filter(o => o.rating);
  const avgRating = rated.length ? (rated.reduce((s, o) => s + o.rating, 0) / rated.length).toFixed(1) : null;

  // Crop ripeness trend, last 7 days
  const cropByDay = days.map(day => {
    const dayReadings = cropReadings.filter(r => new Date(r.timestamp).toISOString().slice(0, 10) === day);
    return {
      day,
      ripe: dayReadings.filter(r => r.status === 'Ripe').length,
      nearly: dayReadings.filter(r => r.status === 'Nearly ripe').length,
      unripe: dayReadings.filter(r => r.status === 'Unripe').length
    };
  });

  res.json({
    perDay,
    avgDeliveryMinutes,
    avgRating,
    ratedCount: rated.length,
    batteryHistory: batteryLog.slice(-100),
    cropByDay,
    totals: {
      outdoor: orders.length,
      indoor: indoorOrders.length,
      farming: farmingOrders.length,
      delivered: allDelivered.length
    }
  });
});

// ---- PAYMENT (stub — see README for what real integration needs) ----
app.post('/api/orders/:id/pay', requireLogin, (req, res) => {
  const o = findAnyOrder(req.params.id);
  if (!o) return res.status(404).json({ error: 'not found' });
  if (o.customerId !== req.session.user.id) return res.status(403).json({ error: 'Not your order' });
  // Real integration would call a payment provider's API here (e.g. MTN
  // MoMo, Airtel Money, Stripe) and only mark paid after it confirms.
  console.log(`[PAYMENT STUB] Would charge ${req.body.amount || '?'} for order ${o.id} via ${req.body.method || 'unknown method'}`);
  o.paid = true;
  o.paymentAmount = req.body.amount || null;
  o.paymentMethod = req.body.method || null;
  saveWhicheverList(o);
  sendSMS(o.phone, `Payment received for order ${o.id}. Thank you! Tap your card on ROVER-01 when it arrives to unlock your package.`);
  io.to('order:' + o.id).emit('order:update', o);
  res.json({ ok: true, note: 'Payment stubbed — no real charge was made.' });
});

// Fixed starting point for new deliveries — change to wherever your
// actual warehouse/pickup point is.
const WAREHOUSE_POS = { lat: -1.9553, lng: 30.0912 };

function findUserById(id) { return users.find(u => u.id === id); }

// Does this logged-in customer already have a delivery in progress?
// Used so they don't accidentally create duplicate orders.
app.get('/api/orders/mine', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only.' });
  const mine = orders
    .filter(o => o.customerId === req.session.user.id && o.status !== 'delivered')
    .sort((a, b) => b.createdAt - a.createdAt);
  res.json(mine[0] || null);
});

// Customer places a new delivery order — address + a point picked on the map.
app.post('/api/orders/create', requireLogin, (req, res) => {
  if (req.session.user.role !== 'customer') return res.status(403).json({ error: 'Customers only.' });
  const { address, lat, lng, priority } = req.body;
  if (!address || lat == null || lng == null) {
    return res.status(400).json({ error: 'Address and a map location are required.' });
  }
  const user = findUserById(req.session.user.id);
  const dest = { lat: Number(lat), lng: Number(lng) };
  const o = {
    id: 'ORD-' + Math.floor(1000 + Math.random() * 9000),
    customerId: user.id,
    customer: user.fullName,
    phone: user.phone,
    address,
    status: 'queued',
    priority: !!priority,
    pos: { ...WAREHOUSE_POS },
    dest,
    totalDistKm: distanceKm(WAREHOUSE_POS, dest),
    createdAt: Date.now()
  };
  o.distanceKm = o.totalDistKm;
  o.etaMin = Math.max(1, Math.round(o.totalDistKm * 8));
  orders.push(o);
  saveOrders(orders);
  io.to('admin').emit('order:new', o);
  res.status(201).json({ ok: true, id: o.id });
});

// ---------------------------------------------------------------------------
// AUTH — register, login (customer + admin), logout, current-user check
// ---------------------------------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { fullName, email, phone, password, deliveryType } = req.body;
  if (!fullName || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'That email is already registered.' });
  }
  const VALID_TYPES = ['outdoor', 'indoor', 'farming'];
  const user = {
    id: 'USR-' + Math.floor(10000 + Math.random() * 89999),
    fullName, email, phone: phone || '',
    passwordHash: bcrypt.hashSync(password, 10),
    role: 'customer',
    deliveryType: VALID_TYPES.includes(deliveryType) ? deliveryType : 'outdoor', // defaults to outdoor
    createdAt: Date.now()
  };
  users.push(user);
  saveUsers(users);
  res.status(201).json({ ok: true });
});

const DELIVERY_TYPE_REDIRECT = {
  outdoor: 'order.html',
  indoor: 'indoor-order.html',
  farming: 'farming-order.html'
};

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email.toLowerCase() === (email || '').toLowerCase() && u.role === 'customer');
  if (!user || !bcrypt.compareSync(password || '', user.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  const deliveryType = DELIVERY_TYPE_REDIRECT[user.deliveryType] ? user.deliveryType : 'outdoor';
  req.session.user = { id: user.id, fullName: user.fullName, role: 'customer', deliveryType };
  res.json({ ok: true, redirect: DELIVERY_TYPE_REDIRECT[deliveryType] });
});

app.post('/api/auth/admin-login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email.toLowerCase() === (email || '').toLowerCase() && u.role === 'admin');
  if (!user || !bcrypt.compareSync(password || '', user.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  req.session.user = { id: user.id, fullName: user.fullName, role: 'admin' };
  res.json({ ok: true, redirect: 'admin-dashboard.html' });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/auth/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
  res.json(req.session.user);
});

// ---------------------------------------------------------------------------
// PLAIN-HTTP ENDPOINTS FOR THE ESP32
// The ESP32 firmware calls these directly with HTTPClient — no Socket.IO
// library needed on the microcontroller side.
// ---------------------------------------------------------------------------

// ESP32 polls this every ~300ms to find out what the admin dashboard wants
// it to do right now.
app.get('/api/robot/poll', (req, res) => res.json(robotState));

// A future indoor-capable robot would poll this instead of the endpoint
// above — separate command channel, one per indoor order.
app.get('/api/indoor-robot/poll/:orderId', (req, res) => {
  res.json(getIndoorState(req.params.orderId));
});

// Shared logic — used by both the plain-HTTP endpoint (for the ESP32,
// which can't easily speak Socket.IO) and the Socket.IO handler below
// (for the simulator, or a future Pi that CAN use Socket.IO).
function handleTelemetry({ orderId, pos, battery, speed, gpsSats }) {
  if (!orderId || !pos) return null;
  const o = findOrder(orderId);
  if (!o) return null;
  o.pos = pos; o.battery = battery; o.speed = speed; o.gpsSats = gpsSats;
  o.distanceKm = distanceKm(pos, o.dest);
  o.etaMin = Math.max(0, Math.round(o.distanceKm * 8));
  saveOrders(orders);
  logBattery(battery);
  const robot = robots.find(r => r.id === 'ROVER-01');
  if (robot) { robot.battery = battery; robot.status = 'active'; robot.lastSeen = Date.now(); saveRobots(robots); }
  io.to('admin').emit('telemetry', o);
  io.to('order:' + o.id).emit('order:update', o);
  return o;
}

function handleRfid({ orderId, cardId }) {
  const o = findOrder(orderId);
  if (!o) return null;

  // Payment acts as verification — the card won't unlock the
  // compartment unless the customer has already paid. This is the
  // deliberate security purpose of the RFID tap, not just a formality.
  if (!o.paid) {
    io.to('admin').emit('log', { message: `RFID tap REJECTED: ${o.id} — payment not completed`, level: 'crit' });
    io.to('order:' + o.id).emit('rfid:rejected', {
      reason: 'Payment required before the compartment can unlock.'
    });
    return { rejected: true, reason: 'payment_required', order: o };
  }

  o.status = 'delivered';
  o.deliveredAt = Date.now();
  saveOrders(orders);
  sendSMS(o.phone, `Hi ${o.customer}, your package (${o.id}) was just delivered and unlocked. Thank you!`);
  io.to('admin').emit('log', { message: `RFID unlock: ${o.id} (card ${cardId})`, level: 'info' });
  io.to('admin').emit('order:update', o);
  io.to('order:' + o.id).emit('order:update', o);
  return o;
}

// ESP32 posts status here periodically. orderId/lat/lng are optional —
// send them once your GPS module is wired in; battery/distanceCm work
// with or without GPS.
app.post('/api/robot/telemetry', (req, res) => {
  const { orderId, lat, lng, battery, distanceCm, speed, gpsSats } = req.body;

  if (orderId && lat != null && lng != null) {
    handleTelemetry({ orderId, pos: { lat, lng }, battery, speed, gpsSats });
  }

  io.to('admin').emit('log', {
    message: `ESP32 status — battery ${battery ?? '?'}%, front distance ${distanceCm ?? '?'}cm`,
    level: ''
  });
  res.json({ ok: true });
});

// ESP32 posts here the moment the RC522 detects a card tap.
app.post('/api/robot/rfid', (req, res) => {
  const { orderId, cardId } = req.body;
  const result = handleRfid({ orderId, cardId });
  if (!result) return res.status(404).json({ error: 'Order not found' });
  if (result.rejected) return res.status(402).json({ ok: false, reason: result.reason });
  res.json({ ok: true });
});

// ---------------------------------------------------------------------------
// SOCKET.IO — real-time hub
//
// Rooms:
//   'admin'          - all connected admin dashboards
//   'robot'          - the robot's own connection (Pi/ESP32 side)
//   'order:<ID>'     - customers watching one specific order
//
// Events IN (from robot):
//   robot:telemetry  { orderId, pos:{lat,lng}, battery, speed, gpsSats }
//   robot:radar      { distAngle: [n,n,n,n,n] }   // your 5-point sweep
//   robot:log        { message, level }
//   robot:rfid       { orderId, cardId }           // triggers delivery + SMS
//
// Events IN (from admin dashboard):
//   admin:cmd        { action: 'forward'|'backward'|'left'|'right'|'stop' }
//   admin:mode       { auto: true|false }
//   admin:stop       (no payload — emergency stop)
//
// Events OUT (to admin):        telemetry, radar, log, order:new
// Events OUT (to robot):        cmd, mode, stop
// Events OUT (to order:<ID>):   order:update
// ---------------------------------------------------------------------------
io.on('connection', (socket) => {
  console.log('client connected:', socket.id);

  socket.on('identify', ({ role, orderId }) => {
    socket.data.role = role;
    if (role === 'admin') socket.join('admin');
    if (role === 'robot') socket.join('robot');
    if (role === 'customer' && orderId) socket.join('order:' + orderId);
    console.log(`  -> identified as ${role}${orderId ? ' for ' + orderId : ''}`);
  });

  socket.on('subscribe:order', (orderId) => {
    socket.join('order:' + orderId);
    const o = findOrder(orderId);
    if (o) socket.emit('order:update', o);
  });

  // ---- FROM CUSTOMER (indoor joystick, driving their OWN order only) ----
  // Room-scoped to "order:<id>" — a customer can only steer the order
  // they're actually viewing, never someone else's.
  socket.on('customer:indoor-cmd', ({ orderId, action }) => {
    if (!orderId || !socket.rooms.has('order:' + orderId)) return;
    getIndoorState(orderId).action = action;
    io.to('admin').emit('log', { message: `Indoor joystick (${orderId}): ${action}`, level: '' });
  });
  socket.on('customer:indoor-stop', ({ orderId }) => {
    if (!orderId || !socket.rooms.has('order:' + orderId)) return;
    getIndoorState(orderId).action = 'stop';
  });

  // ---- CHAT ----
  socket.on('chat:send', ({ orderId, from, text }) => {
    if (!orderId || !text) return;
    const msg = {
      id: 'MSG-' + Math.floor(100000 + Math.random() * 899999),
      orderId, from: from === 'admin' ? 'admin' : 'customer',
      text: String(text).slice(0, 1000),
      timestamp: Date.now()
    };
    chatMessages.push(msg);
    if (chatMessages.length > 2000) chatMessages = chatMessages.slice(-2000);
    saveChat(chatMessages);
    io.to('order:' + orderId).emit('chat:message', msg);
    io.to('admin').emit('chat:message', msg);
  });

  // ---- FROM ROBOT ----
  socket.on('robot:telemetry', (data) => handleTelemetry(data));
  socket.on('robot:radar', (data) => io.to('admin').emit('radar', data));
  socket.on('robot:log', (data) => io.to('admin').emit('log', data));
  socket.on('robot:rfid', (data) => handleRfid(data));

  // ---- FROM ADMIN ----
  socket.on('admin:cmd', (payload) => {
    robotState.command = payload;
    io.to('robot').emit('cmd', payload);
  });
  socket.on('admin:mode', (payload) => {
    robotState.mode = payload;
    io.to('robot').emit('mode', payload);
  });
  socket.on('admin:stop', () => {
    robotState.command = { action: 'stop' };
    io.to('robot').emit('stop');
  });

  socket.on('disconnect', () => console.log('client disconnected:', socket.id));
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`ROVER-01 running on http://localhost:${PORT}`);
  console.log(`Open http://localhost:${PORT}/login.html to get started`);
});
