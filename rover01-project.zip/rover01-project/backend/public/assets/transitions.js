// ROVER-01 — shared page transitions.
// Include this on every page (with either bg-light.css or bg-dark.css)
// to get: a fade-in on load, a fade-out before leaving, and automatic
// smooth transitions on normal internal links. For redirects triggered
// from JavaScript (after login, after placing an order, etc.), call
// go('some-page.html') instead of setting window.location.href directly.

(function () {
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var style = document.createElement('style');
  style.textContent =
    'body.rover-page-enter{opacity:0;transform:translateY(8px);}' +
    'body.rover-page-enter-active{opacity:1;transform:translateY(0);transition:opacity .38s ease,transform .38s ease;}' +
    'body.rover-page-exit{opacity:0!important;transform:translateY(-6px);transition:opacity .26s ease,transform .26s ease;}' +
    '@media (prefers-reduced-motion: reduce){' +
    '  body.rover-page-enter,body.rover-page-enter-active,body.rover-page-exit{opacity:1!important;transform:none!important;transition:none!important;}' +
    '}';
  document.head.appendChild(style);

  document.addEventListener('DOMContentLoaded', function () {
    document.body.classList.add('rover-page-enter');
    requestAnimationFrame(function () {
      document.body.classList.add('rover-page-enter-active');
    });
  });

  // Programmatic redirect with a fade-out first. Use this instead of
  // `window.location.href = url` after actions like login/submit.
  window.go = function (url) {
    if (reduced) { window.location.href = url; return; }
    document.body.classList.add('rover-page-exit');
    setTimeout(function () { window.location.href = url; }, 240);
  };

  // Automatically fade-transition plain internal links, e.g.
  // <a href="login.html">...</a>, without needing every page edited.
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('http') ||
        a.target === '_blank' || a.hasAttribute('data-no-transition') ||
        a.getAttribute('onclick')) return;
    e.preventDefault();
    window.go(href);
  });
  // ---- PWA: manifest link + service worker registration ----
  // Added automatically to every page that includes this file.
  if (!document.querySelector('link[rel="manifest"]')) {
    var manifestLink = document.createElement('link');
    manifestLink.rel = 'manifest';
    manifestLink.href = '/manifest.json';
    document.head.appendChild(manifestLink);
  }
  if (!document.querySelector('meta[name="theme-color"]')) {
    var themeMeta = document.createElement('meta');
    themeMeta.name = 'theme-color';
    themeMeta.content = '#e08a1f';
    document.head.appendChild(themeMeta);
  }
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/service-worker.js').catch(function () {});
    });
  }
})();
