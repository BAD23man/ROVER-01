// ROVER-01 — dark/light mode toggle for customer-facing pages.
// Every customer page already defines the same :root variable names
// (--bg, --card, --ink, etc.) so one shared override here works
// everywhere without touching each page's own <style> block.

(function () {
  var STORAGE_KEY = 'rover-theme';
  var saved = localStorage.getItem(STORAGE_KEY);
  if (saved === 'dark') document.documentElement.classList.add('rover-dark');

  var style = document.createElement('style');
  style.textContent =
    ':root.rover-dark{' +
    '  --bg:#15120c; --card:#221c14; --line:#3a3125;' +
    '  --ink:#f3ece0; --ink-dim:#c2b39d; --ink-faint:#8f8067;' +
    '  --amber:#f0a63a; --amber-soft:#4a3820;' +
    '  --red:#ff6b5e; --red-soft:#3a1f1c;' +
    '  --green:#4fd486; --green-soft:#173324;' +
    '}' +
    ':root.rover-dark body{background:var(--bg); color:var(--ink);}' +
    '.rover-theme-toggle{' +
    '  position:fixed; top:16px; right:16px; z-index:80;' +
    '  width:42px; height:42px; border-radius:50%; border:1px solid var(--line);' +
    '  background:var(--card); color:var(--ink); display:flex; align-items:center; justify-content:center;' +
    '  cursor:pointer; box-shadow:0 4px 14px rgba(0,0,0,.14); font-size:18px; transition:transform .15s;' +
    '}' +
    '.rover-theme-toggle:hover{transform:scale(1.06);}' +
    '@media (prefers-reduced-motion: reduce){ .rover-theme-toggle{transition:none;} }';
  document.head.appendChild(style);

  document.addEventListener('DOMContentLoaded', function () {
    var btn = document.createElement('button');
    btn.className = 'rover-theme-toggle';
    btn.setAttribute('aria-label', 'Toggle dark mode');
    btn.textContent = document.documentElement.classList.contains('rover-dark') ? '\u2600\uFE0F' : '\uD83C\uDF19';
    btn.onclick = function () {
      document.documentElement.classList.toggle('rover-dark');
      var isDark = document.documentElement.classList.contains('rover-dark');
      localStorage.setItem(STORAGE_KEY, isDark ? 'dark' : 'light');
      btn.textContent = isDark ? '\u2600\uFE0F' : '\uD83C\uDF19';
    };
    document.body.appendChild(btn);
  });
})();
