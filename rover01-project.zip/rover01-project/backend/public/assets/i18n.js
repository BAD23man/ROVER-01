// ROVER-01 — lightweight i18n. Add `data-i18n="key"` to any element's
// text content (or `data-i18n-placeholder="key"` for inputs) and it gets
// swapped automatically based on the chosen language, persisted across
// visits. To translate a new page: add data-i18n attributes to its
// elements, and add matching keys to the three dictionaries below.

(function () {
  var STORAGE_KEY = 'rover-lang';
  var DICT = {
    en: {
      brand: 'ROVER01',
      login_title: 'Welcome back',
      login_sub: 'Log in to track your deliveries.',
      login_email: 'Email',
      login_password: 'Password',
      login_button: 'Log in',
      login_no_account: "No account yet?",
      login_create: 'Create one',
      login_admin_link: 'Admin login',
      register_title: 'Create your account',
      register_sub: 'Register to track your deliveries.',
      register_fullname: 'Full name',
      register_phone: 'Phone (for delivery SMS)',
      register_confirm: 'Confirm password',
      register_where: 'Where will your deliveries happen?',
      register_button: 'Create account',
      register_have_account: 'Already have an account?',
      register_login: 'Log in'
    },
    fr: {
      brand: 'ROVER01',
      login_title: 'Bon retour',
      login_sub: 'Connectez-vous pour suivre vos livraisons.',
      login_email: 'E-mail',
      login_password: 'Mot de passe',
      login_button: 'Se connecter',
      login_no_account: "Pas encore de compte ?",
      login_create: 'Créer un compte',
      login_admin_link: 'Connexion admin',
      register_title: 'Créez votre compte',
      register_sub: 'Inscrivez-vous pour suivre vos livraisons.',
      register_fullname: 'Nom complet',
      register_phone: 'Téléphone (pour SMS de livraison)',
      register_confirm: 'Confirmer le mot de passe',
      register_where: 'Où se dérouleront vos livraisons ?',
      register_button: 'Créer un compte',
      register_have_account: 'Vous avez déjà un compte ?',
      register_login: 'Se connecter'
    },
    rw: {
      brand: 'ROVER01',
      login_title: 'Murakaza neza',
      login_sub: 'Injira urebe aho ibicuruzwa byawe bigeze.',
      login_email: 'Imeli',
      login_password: 'Ijambo ry\'ibanga',
      login_button: 'Injira',
      login_no_account: 'Nta konti ufite?',
      login_create: 'Fungura konti',
      login_admin_link: 'Kwinjira nk\'umuyobozi',
      register_title: 'Fungura konti yawe',
      register_sub: 'Iyandikishe kugira ngo urebe aho ibicuruzwa byawe bigeze.',
      register_fullname: 'Amazina yombi',
      register_phone: 'Telefoni (kubutumwa bugufi bw\'igicuruzwa)',
      register_confirm: 'Emeza ijambo ry\'ibanga',
      register_where: 'Ibicuruzwa byawe bizajya bigeze he?',
      register_button: 'Fungura konti',
      register_have_account: 'Ufite konti?',
      register_login: 'Injira'
    }
  };

  var current = localStorage.getItem(STORAGE_KEY) || 'en';

  function applyTranslations() {
    var dict = DICT[current] || DICT.en;
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var key = el.getAttribute('data-i18n');
      if (dict[key]) el.textContent = dict[key];
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-placeholder');
      if (dict[key]) el.setAttribute('placeholder', dict[key]);
    });
  }

  var style = document.createElement('style');
  style.textContent =
    '.rover-lang-switch{position:fixed;top:16px;right:66px;z-index:80;display:flex;gap:4px;' +
    'background:var(--card);border:1px solid var(--line);border-radius:20px;padding:4px;box-shadow:0 4px 14px rgba(0,0,0,.1);}' +
    '.rover-lang-switch button{border:none;background:none;padding:6px 9px;border-radius:16px;font-family:var(--mono,monospace);' +
    'font-size:10px;font-weight:600;color:var(--ink-dim,#888);cursor:pointer;}' +
    '.rover-lang-switch button.active{background:var(--amber,#e08a1f);color:#fff;}';
  document.head.appendChild(style);

  document.addEventListener('DOMContentLoaded', function () {
    var wrap = document.createElement('div');
    wrap.className = 'rover-lang-switch';
    ['en', 'fr', 'rw'].forEach(function (lang) {
      var btn = document.createElement('button');
      btn.textContent = lang.toUpperCase();
      btn.className = lang === current ? 'active' : '';
      btn.onclick = function () {
        current = lang;
        localStorage.setItem(STORAGE_KEY, lang);
        wrap.querySelectorAll('button').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        applyTranslations();
      };
      wrap.appendChild(btn);
    });
    document.body.appendChild(wrap);
    applyTranslations();
  });
})();
