// ROVER-01 mascot — an animated cartoon robot moving along a route,
// drawn as one background scene. Reads body[data-scene] to choose
// between "outdoor" (road + buildings) and "indoor" (hallway + doors).
// This replaces the old faint dashed-line background with something
// that actually feels alive.

(function () {
  var scene = document.body.getAttribute('data-scene') || 'outdoor';
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var svgNS = 'http://www.w3.org/2000/svg';

  function el(tag, attrs) {
    var e = document.createElementNS(svgNS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }

  // ---- Scene layout: the route path + scenery decorations ----
  var pathD, decorations, waypoints;

  if (scene === 'indoor') {
    pathD = 'M -40 380 L 220 380 L 220 180 L 520 180 L 520 560 L 900 560';
    waypoints = [
      { x: -40, y: 380 }, { x: 220, y: 380 }, { x: 220, y: 180 },
      { x: 520, y: 180 }, { x: 520, y: 560 }, { x: 900, y: 560 }
    ];
    decorations = [
      { type: 'door', x: 160, y: 350 }, { type: 'door', x: 470, y: 150 },
      { type: 'door', x: 820, y: 530 }, { type: 'door', x: 60, y: 350 }
    ];
  } else if (scene === 'farming') {
    pathD = 'M -40 200 L 900 200 M -40 400 L 900 400 M -40 600 L 900 600';
    waypoints = [
      { x: -40, y: 200 }, { x: 900, y: 200 }, { x: 900, y: 400 },
      { x: -40, y: 400 }, { x: -40, y: 600 }, { x: 900, y: 600 }
    ];
    decorations = [];
    // rows of little crop dots
    for (var row = 0; row < 3; row++) {
      for (var i = 0; i < 12; i++) {
        decorations.push({ type: 'crop', x: 20 + i * 74, y: 160 + row * 200 });
      }
    }
  } else {
    pathD = 'M -40 480 C 140 340, 300 620, 480 440 S 720 260, 900 400';
    waypoints = [
      { x: -40, y: 480 }, { x: 210, y: 400 }, { x: 480, y: 440 },
      { x: 690, y: 300 }, { x: 900, y: 400 }
    ];
    decorations = [
      { type: 'building', x: 110, y: 240, h: 130 }, { type: 'tree', x: 340, y: 500 },
      { type: 'building', x: 560, y: 160, h: 190 }, { type: 'tree', x: 780, y: 480 },
      { type: 'building', x: 30, y: 480, h: 90 }
    ];
  }

  // ---- Build the SVG scene ----
  var wrap = document.createElement('div');
  wrap.setAttribute('aria-hidden', 'true');
  wrap.className = 'rover-mascot-wrap';
  wrap.style.cssText = 'position:fixed;inset:0;z-index:-2;pointer-events:none;overflow:hidden;';

  var svg = el('svg', { viewBox: '0 0 900 700', preserveAspectRatio: 'xMidYMid slice' });
  svg.style.cssText = 'width:100%;height:100%;';

  var routeColor = el('style', {});
  routeColor.textContent = '.rover-scene{color:var(--amber, #e08a1f);}';
  svg.appendChild(routeColor);

  var sceneGroup = el('g', { class: 'rover-scene', opacity: '0.22' });

  // route line
  sceneGroup.appendChild(el('path', {
    d: pathD, fill: 'none', stroke: 'currentColor', 'stroke-width': '5',
    'stroke-linecap': 'round', 'stroke-dasharray': '2 16'
  }));

  // scenery
  decorations.forEach(function (d) {
    if (d.type === 'building') {
      sceneGroup.appendChild(el('rect', { x: d.x, y: d.y, width: 55, height: d.h, rx: 6, fill: 'currentColor' }));
    } else if (d.type === 'tree') {
      var g = el('g', {});
      g.appendChild(el('rect', { x: d.x - 4, y: d.y, width: 8, height: 30, fill: 'currentColor' }));
      g.appendChild(el('circle', { cx: d.x, cy: d.y - 14, r: 22, fill: 'currentColor' }));
      sceneGroup.appendChild(g);
    } else if (d.type === 'door') {
      sceneGroup.appendChild(el('rect', { x: d.x, y: d.y, width: 34, height: 62, rx: 4, fill: 'currentColor' }));
    } else if (d.type === 'crop') {
      sceneGroup.appendChild(el('circle', { cx: d.x, cy: d.y, r: 8, fill: 'currentColor' }));
    }
  });

  svg.appendChild(sceneGroup);

  // ---- The robot itself, animated along the waypoints ----
  var bot = el('g', { class: reduced ? 'rover-bot rover-bot-static' : 'rover-bot' });
  bot.appendChild(el('rect', { x: -15, y: -11, width: 30, height: 22, rx: 7, fill: '#e08a1f' }));
  bot.appendChild(el('circle', { cx: -8, cy: -3, r: 3, fill: '#fff' }));
  bot.appendChild(el('circle', { cx: 8, cy: -3, r: 3, fill: '#fff' }));
  bot.appendChild(el('line', { x1: 0, y1: -11, x2: 0, y2: -19, stroke: '#e08a1f', 'stroke-width': '2.5' }));
  bot.appendChild(el('circle', { cx: 0, cy: -21, r: 4, fill: '#e08a1f' }));
  bot.appendChild(el('circle', { cx: -9, cy: 13, r: 5.5, fill: '#1c1a17' }));
  bot.appendChild(el('circle', { cx: 9, cy: 13, r: 5.5, fill: '#1c1a17' }));
  bot.style.opacity = '0.5';
  svg.appendChild(bot);

  wrap.appendChild(svg);
  document.body.appendChild(wrap);

  // ---- Keyframe animation moving the robot through the waypoints ----
  if (!reduced) {
    var pct = [];
    for (var i = 0; i < waypoints.length; i++) pct.push((i / (waypoints.length - 1) * 100).toFixed(1));

    var kfName = 'roverBotMove_' + scene;
    var kf = '@keyframes ' + kfName + '{';
    waypoints.forEach(function (wp, i) {
      kf += pct[i] + '%{transform:translate(' + wp.x + 'px,' + wp.y + 'px);}';
    });
    kf += '}';

    var style = document.createElement('style');
    style.textContent = kf +
      '.rover-bot{animation:' + kfName + ' 14s ease-in-out infinite;}';
    document.head.appendChild(style);
  } else {
    bot.setAttribute('transform', 'translate(' + waypoints[0].x + ',' + waypoints[0].y + ')');
  }
})();
