// ROVER-01 — shared cute robot marker for Leaflet maps. Used on both the
// customer tracking page and the admin dashboard so the "robot on the
// map" looks the same everywhere: a small cartoon robot that gently bobs
// as it moves, instead of a plain colored dot.

function roverRobotDivIcon() {
  var html =
    '<div class="rover-map-bot">' +
    '<svg viewBox="0 0 40 40" width="36" height="36">' +
    '<line x1="20" y1="14" x2="20" y2="7" stroke="#fff" stroke-width="3" stroke-linecap="round"/>' +
    '<circle cx="20" cy="6" r="3.4" fill="#fff"/>' +
    '<rect x="7" y="13" width="26" height="17" rx="7" fill="#e08a1f" stroke="#fff" stroke-width="2"/>' +
    '<circle cx="14.5" cy="21" r="2.8" fill="#fff"/>' +
    '<circle cx="25.5" cy="21" r="2.8" fill="#fff"/>' +
    '<circle cx="12" cy="32" r="4.2" fill="#1c1a17" stroke="#fff" stroke-width="1.5"/>' +
    '<circle cx="28" cy="32" r="4.2" fill="#1c1a17" stroke="#fff" stroke-width="1.5"/>' +
    '</svg>' +
    '</div>';

  return L.divIcon({
    html: html,
    className: 'rover-map-bot-wrap',
    iconSize: [36, 36],
    iconAnchor: [18, 24]
  });
}

function roverFlagDivIcon(color) {
  var html =
    '<svg viewBox="0 0 30 40" width="26" height="34">' +
    '<path d="M5 38 L5 4" stroke="' + color + '" stroke-width="3" stroke-linecap="round"/>' +
    '<path d="M5 4 L24 10 L5 16 Z" fill="' + color + '"/>' +
    '</svg>';
  return L.divIcon({ html: html, className: '', iconSize: [26, 34], iconAnchor: [5, 34] });
}

(function () {
  var style = document.createElement('style');
  style.textContent =
    '@keyframes rover-bot-bob{0%,100%{transform:translateY(0);}50%{transform:translateY(-3px);}}' +
    '.rover-map-bot{animation:rover-bot-bob 1.1s ease-in-out infinite;}' +
    '.rover-map-bot-wrap{transition:transform .6s linear;}' +
    '@media (prefers-reduced-motion: reduce){.rover-map-bot{animation:none;}}';
  document.head.appendChild(style);
})();
