// ROVER-01 — shared chat widget. Include on any tracking page (with
// ORDER_ID and a `socket` already defined) to get a floating chat button
// that opens a panel talking to admin support for that specific order.

(function () {
  if (typeof ORDER_ID === 'undefined' || typeof socket === 'undefined') return;

  var style = document.createElement('style');
  style.textContent =
    '.rover-chat-btn{position:fixed;bottom:20px;right:20px;z-index:90;width:52px;height:52px;border-radius:50%;' +
    'background:var(--amber);color:#fff;border:none;box-shadow:0 6px 18px rgba(0,0,0,.2);cursor:pointer;font-size:22px;}' +
    '.rover-chat-panel{position:fixed;bottom:82px;right:20px;z-index:90;width:300px;max-width:calc(100vw - 40px);' +
    'height:380px;background:var(--card);border:1px solid var(--line);border-radius:16px;box-shadow:0 14px 40px rgba(0,0,0,.18);' +
    'display:none;flex-direction:column;overflow:hidden;}' +
    '.rover-chat-panel.open{display:flex;}' +
    '.rover-chat-head{padding:12px 14px;border-bottom:1px solid var(--line);font-family:var(--mono,monospace);font-size:11px;' +
    'font-weight:600;color:var(--ink-dim);display:flex;justify-content:space-between;align-items:center;}' +
    '.rover-chat-head button{background:none;border:none;color:var(--ink-faint);cursor:pointer;font-size:16px;}' +
    '.rover-chat-body{flex:1;overflow-y:auto;padding:10px 12px;display:flex;flex-direction:column;gap:8px;}' +
    '.rover-chat-msg{max-width:80%;padding:8px 11px;border-radius:12px;font-size:12.5px;line-height:1.4;}' +
    '.rover-chat-msg.customer{align-self:flex-end;background:var(--amber);color:#fff;border-bottom-right-radius:3px;}' +
    '.rover-chat-msg.admin{align-self:flex-start;background:var(--bg);border:1px solid var(--line);border-bottom-left-radius:3px;}' +
    '.rover-chat-input-row{display:flex;border-top:1px solid var(--line);padding:8px;gap:6px;}' +
    '.rover-chat-input-row input{flex:1;border:1px solid var(--line);border-radius:20px;padding:8px 12px;font-size:12.5px;' +
    'background:var(--bg);color:var(--ink);}' +
    '.rover-chat-input-row button{background:var(--amber);color:#fff;border:none;border-radius:50%;width:34px;height:34px;cursor:pointer;}';
  document.head.appendChild(style);

  document.addEventListener('DOMContentLoaded', function () {
    var btn = document.createElement('button');
    btn.className = 'rover-chat-btn';
    btn.innerHTML = '\uD83D\uDCAC';
    btn.setAttribute('aria-label', 'Chat with support');

    var panel = document.createElement('div');
    panel.className = 'rover-chat-panel';
    panel.innerHTML =
      '<div class="rover-chat-head"><span>SUPPORT CHAT</span><button id="roverChatClose">\u2715</button></div>' +
      '<div class="rover-chat-body" id="roverChatBody"></div>' +
      '<div class="rover-chat-input-row"><input id="roverChatInput" placeholder="Type a message…" maxlength="500">' +
      '<button id="roverChatSend">\u2191</button></div>';

    document.body.appendChild(btn);
    document.body.appendChild(panel);

    btn.onclick = function () {
      panel.classList.toggle('open');
      if (panel.classList.contains('open')) loadHistory();
    };
    document.getElementById('roverChatClose').onclick = function () { panel.classList.remove('open'); };

    function addMsg(m) {
      var body = document.getElementById('roverChatBody');
      var div = document.createElement('div');
      div.className = 'rover-chat-msg ' + (m.from === 'admin' ? 'admin' : 'customer');
      div.textContent = m.text;
      body.appendChild(div);
      body.scrollTop = body.scrollHeight;
    }

    function loadHistory() {
      fetch('/api/chat/' + ORDER_ID).then(function (r) { return r.json(); }).then(function (list) {
        var body = document.getElementById('roverChatBody');
        body.innerHTML = '';
        list.forEach(addMsg);
      });
    }

    function send() {
      var input = document.getElementById('roverChatInput');
      var text = input.value.trim();
      if (!text) return;
      socket.emit('chat:send', { orderId: ORDER_ID, from: 'customer', text: text });
      input.value = '';
    }
    document.getElementById('roverChatSend').onclick = send;
    document.getElementById('roverChatInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') send();
    });

    socket.on('chat:message', function (m) {
      if (m.orderId !== ORDER_ID) return;
      addMsg(m);
    });
  });
})();
