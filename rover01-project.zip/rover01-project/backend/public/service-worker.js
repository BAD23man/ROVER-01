// ROVER-01 — basic service worker. Caches the app's own static pages
// and assets so they still open (in a limited, read-only way) without a
// connection. API calls (orders, telemetry, etc.) always go to the
// network — this never caches live data, only the app shell itself.

const CACHE_NAME = 'rover01-shell-v1';
const SHELL_FILES = [
  '/login.html',
  '/register.html',
  '/order.html',
  '/indoor-order.html',
  '/farming-order.html',
  '/history.html',
  '/assets/card-style.css',
  '/assets/bg-light.css',
  '/assets/mascot.js',
  '/assets/theme-toggle.js',
  '/assets/transitions.js',
  '/assets/robot-icon.js',
  '/assets/chat-widget.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {})
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  // Never cache API calls — those need to always be live.
  if (url.pathname.startsWith('/api/')) return;

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
