// Pretends to be the robot (Raspberry Pi side) sending real telemetry,
// radar sweeps, and an RFID tap once it "arrives." Use this to test the
// admin dashboard and customer page end-to-end before your hardware and
// firmware are ready.
//
// Usage:
//   node robot-simulator.js ORD-1042

const { io } = require('socket.io-client');

const orderId = process.argv[2] || 'ORD-1042';
const socket = io('http://localhost:4000');

let pos = { lat: -1.9553, lng: 30.0912 };
const dest = { lat: -1.9441, lng: 30.0619 };
let arrived = false;

function distanceKm(a, b) {
  const R = 6371;
  const dLat = (b.lat - a.lat) * Math.PI / 180;
  const dLng = (b.lng - a.lng) * Math.PI / 180;
  const lat1 = a.lat * Math.PI / 180;
  const lat2 = b.lat * Math.PI / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

socket.on('connect', () => {
  console.log(`Robot simulator connected — driving toward ${orderId}`);
  socket.emit('identify', { role: 'robot' });

  socket.emit('robot:log', { message: `Robot online, en route for ${orderId}`, level: '' });

  setInterval(() => {
    if (arrived) return;

    pos.lat += (dest.lat - pos.lat) * 0.02 + (Math.random() - 0.5) * 0.00006;
    pos.lng += (dest.lng - pos.lng) * 0.02 + (Math.random() - 0.5) * 0.00006;

    socket.emit('robot:telemetry', {
      orderId,
      pos,
      battery: Math.round(70 + Math.random() * 10),
      speed: (3.5 + Math.random() * 1.5).toFixed(1),
      gpsSats: 8
    });

    const distLeft = distanceKm(pos, dest);
    if (distLeft < 0.03 && !arrived) {
      arrived = true;
      console.log('Arrived at destination. Waiting, then simulating RFID tap...');
      socket.emit('robot:log', { message: 'Arrived at destination', level: 'warn' });
      setTimeout(() => {
        socket.emit('robot:rfid', { orderId, cardId: 'CARD-8841' });
        console.log('RFID tap sent — delivery marked complete.');
      }, 4000);
    }
  }, 1000);

  // Simulated 5-point ultrasonic sweep, same angles as your ESP32 firmware
  setInterval(() => {
    const distAngle = [160, 125, 90, 55, 20].map(() => Math.round(20 + Math.random() * 180));
    socket.emit('robot:radar', { distAngle });
  }, 1500);
});

// Commands coming down from the admin dashboard land here — this is where
// your real ESP32 serial bridge would forward them to the motor controller.
socket.on('cmd', (payload) => console.log('CMD from admin:', payload));
socket.on('mode', (payload) => console.log('MODE from admin:', payload));
socket.on('stop', () => console.log('EMERGENCY STOP from admin'));

socket.on('connect_error', (err) => console.error('Could not connect to backend:', err.message));
