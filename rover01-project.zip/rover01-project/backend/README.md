# ROVER-01 — Now ONE Server, ONE Folder

This replaces the earlier two-server setup (Node.js + XAMPP/PHP). Login,
registration, the dashboards, and the robot backend all now run from this
one `backend` folder, on one server, started with one command.

You no longer need XAMPP, Apache, PHP, or MySQL for this. Everything uses
Node.js and a simple JSON file for accounts (`users.json`), the same
lightweight approach already used for orders.

## Folder structure now

```
backend/
├── server.js              <- everything: API, Socket.IO, auth, static files
├── create-admin.js         <- run once to make your admin account
├── robot-simulator.js      <- pretends to be the robot for testing
├── package.json
├── users.json              <- auto-created, holds accounts (hashed passwords)
├── orders.json              <- auto-created, holds delivery orders
└── public/                  <- everything the browser loads
    ├── login.html
    ├── register.html
    ├── admin-login.html
    ├── admin-dashboard.html
    └── customer-tracking.html
```

## 1. Install (new dependencies added: bcryptjs, express-session)

```bash
cd backend
npm install
```

## 2. Create your first admin account

Open `create-admin.js`, change the password on the `adminPassword` line to
something only you know, then run:

```bash
node create-admin.js
```

You should see: `Admin account created: admin@rover01.com`

## 3. Start the server

```bash
npm start
```

You should see:
```
ROVER-01 running on http://localhost:4000
Open http://localhost:4000/login.html to get started
```

That's it — **one thing to run**, no XAMPP, no separate ports to juggle.

## 4. Try it

- Customer registration: **http://localhost:4000/register.html**
- Customer login: **http://localhost:4000/login.html**
- Admin login: **http://localhost:4000/admin-login.html**

Register a test customer, log in, you'll land on the tracking page. Log in
with your admin account, you'll land on the dashboard — both pages now
check you're logged in before showing anything (they call `/api/auth/me`
on load and redirect back to the login page if you're not).

## 5. Test with the robot simulator (same as before)

In a second terminal:

```bash
cd backend
npm run simulate ORD-1042
```

## What changed from the XAMPP version

| Before (XAMPP/PHP) | Now (Node.js only) |
|---|---|
| MySQL database, phpMyAdmin | `users.json` file |
| `register.php`, `login.php`, etc. | `register.html` + `/api/auth/...` routes in `server.js` |
| Apache on port 80 | Same Node server, port 4000 |
| Two things to start (XAMPP + `npm start`) | One thing to start (`npm start`) |

The PHP/XAMPP files you built earlier still work fine on their own if you
ever want them — this is just a simpler alternative that avoids running
two separate servers.

## The live map (Leaflet + OpenStreetMap — free, no card, no API key)

The dashboards show a real map with real streets using **Leaflet** (a
free open-source mapping library) and **OpenStreetMap** tiles. Unlike
Google Maps, this needs **zero setup** — no API key, no billing account,
no card. It just works as soon as the page loads, since the map library
and tiles are loaded straight from free public CDNs.

If you ever want Google Maps instead later (e.g. for its Directions API
with real road-following routes), you'd need a Google Cloud billing
account with a card attached — but that's entirely optional; Leaflet is a
genuinely solid free alternative and is what many real apps use.

## What's simulated vs. real right now

The demo coordinates are in Kigali by default — change the `lat`/`lng`
values in `seedOrders()` (server.js) and `robot-simulator.js` to match
wherever you're actually testing. Once a real GPS module is wired to the
robot, its real coordinates replace these automatically — the map code
doesn't change at all, it just displays whatever `pos` it's given.

## The customer flow, end to end

1. Customer registers/logs in at `login.html`
2. Login redirects to `customer-home.html`, which checks: does this
   customer already have an order in progress? (`GET /api/orders/mine`)
   - **No** → shows a form where they tap a location on the map to set
     their delivery address, then submits (`POST /api/orders/place`)
   - **Yes** → skips the form and jumps straight to tracking that order
3. After placing an order, they land on `customer-tracking.html?order=ORD-XXXX`
   — the live map, ETA countdown, and status stepper you already built
4. The admin dashboard's order queue updates live the moment a new order
   comes in (via the `order:new` Socket.IO event)

`WAREHOUSE_POS` in `server.js` is where every new order "starts" from —
change it to your actual depot/warehouse coordinates.

## Indoor delivery (floor plans instead of GPS)

For deliveries inside a building — office, home, hospital — GPS doesn't
work, so this uses a different approach: customers upload a floor plan
image and draw a path across it.

- `public/indoor-order.html` — upload/pick a floor plan, tap points to
  draw a route (start → stop), submit
- Stored in `blueprints.json` (floor plan images, as base64 data) and
  `indoor-orders.json` (each order's waypoint list)
- Admin dashboard logs new indoor orders live via the `indoor-order:new`
  Socket.IO event

**Important limitation to know:** placing this order does **not** yet
make the robot actually follow the drawn path — GPS-based dead-reckoning
or wheel encoders would be needed on the robot side to execute an indoor
route, which is a separate hardware/firmware step. Right now this page
captures *what* the customer wants (the route), ready for whichever
indoor-navigation approach you build next.

## Delivery type: customers pick outdoor or indoor at registration

Registration now asks "Where will your deliveries happen?" — Outdoor or
Indoor. This is stored on the account (`deliveryType`) and controls
routing from then on:

- **Outdoor accounts** → `order.html` (map, pin a location) → 
  `customer-tracking.html` (GPS live map, ETA) — exactly as before
- **Indoor accounts** → `indoor-order.html` (upload/pick a floor plan,
  draw a path) → `indoor-tracking.html` (live camera + animated route
  progress side by side)

Each page checks the logged-in account's type and redirects to the
correct flow if a customer somehow lands on the wrong one — an indoor
account can't accidentally see the outdoor form and vice versa.

**Admin control stays outdoor-only.** The joystick/manual-override panel
on the admin dashboard only ever talks to the outdoor ESP32 — there's no
manual control surface for indoor orders. Indoor orders show up as a log
entry on the admin dashboard (`indoor-order:new`) for visibility, but
admins can't drive an indoor delivery manually; it's meant to run its
drawn route on its own (once real path-execution is built — see the
limitation note above).

**`indoor-tracking.html`'s route-progress animation is simulated** —
it steadily advances a dot along the drawn path over time, since there's
no real position feedback from the robot yet indoors. The camera feed
(if you set `ESP32CAM_IP` in that page) is real. Once real indoor
position tracking exists, `simulateProgress()` in that file is the one
function to replace with real data.

## Animated backgrounds + page transitions

Every page now has:
- A faint, slow-moving animated background tied to what that page is
  about — drifting "route" lines + a GPS-style pulse on customer-facing
  pages, a slow rotating radar wash + scan lines on the admin console
  (echoing the dashboard's own obstacle-sweep panel).
- A smooth fade-in on load, and a fade-out before navigating to another
  page.

This lives in `public/assets/`:
- `bg-light.css` — customer-facing pages (login, register, order,
  indoor-order, customer-tracking, indoor-tracking)
- `bg-dark.css` — admin pages (admin-login, admin-dashboard)
- `transitions.js` — shared by every page; handles the fade in/out and
  auto-transitions plain `<a href="...">` links

**If you add a new page**, include both the right theme's CSS and
`transitions.js` in its `<head>`, same as the existing pages. For a
redirect triggered from JavaScript (after a successful action), call
`go('some-page.html')` instead of setting `window.location.href`
directly — that's what gives it the fade-out instead of an instant jump.
Both respect `prefers-reduced-motion` automatically.

## Animated robot mascot + dark/light mode

Customer-facing pages now have an actual moving cartoon robot in the
background instead of a flat pattern — it travels along a route, looping
continuously:

- **Outdoor pages** (login, register, order, customer-tracking): robot
  moves along a winding road, past simple building/tree silhouettes
- **Indoor pages** (indoor-order, indoor-tracking): robot moves through
  a hallway, past door silhouettes

This lives in `public/assets/mascot.js` — it reads `data-scene="outdoor"`
or `data-scene="indoor"` on `<body>` to pick which layout to draw. If you
add a new page, set that attribute and include the script the same way.

**Dark/light mode**: a floating toggle button (top-right) on every
customer page switches between light and dark, saved in the browser so
it's remembered next visit. This lives in `public/assets/theme-toggle.js`
— it works automatically on any page because every customer page already
shares the same CSS variable names (`--bg`, `--card`, `--ink`, etc.).

The **admin console keeps its own fixed dark ops theme** (radar
sweep + scan lines from `bg-dark.css`) — that's a deliberate identity for
that page, not something admins toggle, since it's meant to read as a
dedicated control room rather than a preference.

Both respect `prefers-reduced-motion` — the mascot simply stops moving
(scene stays visible) if the visitor's browser requests reduced motion.

## Cute robot icon on the maps + polished cards

The plain colored dots on both outdoor maps (customer + admin) are now a
small cartoon robot icon that gently bobs as it moves — `public/assets/
robot-icon.js`, shared by both pages so they stay visually consistent.
The indoor blueprint's tracking dot got the same treatment, drawn
directly on the canvas with a matching bob.

Every card across the customer-facing pages (`public/assets/
card-style.css`) now has real depth (shadow), a brand-colored accent
strip along the top, and a subtle lift on hover.

## Indoor customer joystick (manual override, using their own camera)

On `indoor-tracking.html`, the customer can click **"Take manual
control"** to reveal a joystick right under their live camera feed —
letting them drive the robot themselves for the parts of an indoor route
that are hard to fully automate, steering by what they see on camera.

**This is a separate control channel from the admin's outdoor joystick**
— `customer:indoor-cmd` / `customer:indoor-stop` socket events, backed
by its own `indoorRobotState` object in `server.js`, keyed per order.
Admins still only ever control the outdoor robot; this is customer-only,
and only for their own indoor order.

**Security note, worth knowing before any real deployment:** right now,
whether a socket is "allowed" to drive an order is checked by whether
it has joined that order's Socket.IO room — and joining that room only
requires knowing the order ID string, not proving you're the actual
logged-in customer who placed it. This is fine for testing on your own
machine, but before letting real strangers use this, the room-join
logic needs to check the visitor's actual session (tying Socket.IO
connections to the same login session Express already manages) rather
than trusting the order ID alone.

## Farming — greenhouse crop patrol

A third account type alongside outdoor and indoor. Registration now asks
"Where will your deliveries happen?" with three options; farming
accounts get their own flow:

- `farming-order.html` — upload/pick a greenhouse layout, draw the
  patrol route past your crop rows, then set a **schedule** (once now,
  daily at a chosen time, or every hour)
- `farming-tracking.html` — split view: live camera with a detection-
  style overlay (crop ID, ripeness, confidence %, days to harvest) on
  one side, the greenhouse layout with the robot patrolling the drawn
  route on the other, plus a running log of every reading

Backend: `farming-orders.json` (route + schedule) and
`crop-readings.json` (every detection event), both following the same
JSON-file pattern as everything else. `POST /api/crop-readings` is
ready to receive real data whenever there's a real source for it.

### Update: real crop detection now exists (see ml/ folder)

The description below was accurate when first written — the readings
were purely simulated. That's no longer the whole story: **`ml/`**
contains a real, tested, working computer-vision pipeline
(`color_ripeness_detector.py` + `inference_server.py`) that analyzes
actual photos for real ripeness by color, with no training data needed,
and posts genuine readings into this same backend via
`POST /api/robot/crop-reading`. It was verified end-to-end — a real test
photo produced real detections that were confirmed sitting in the
backend's storage — not just written and assumed to work.

`farming-tracking.html`'s `simulateCropReading()` is still there as a
fallback/demo, but should be deleted once `ml/inference_server.py` is
actually running for a given patrol — see `ml/README.md` for the full
setup, tuning notes, and the upgrade path to a real trained model
(`ml/train_yolo.py`) once you've collected your own labeled photos.

**Update: multi-crop support.** Farmers now pick their actual crop
(tomato, pepper, banana, mango, coffee, strawberry, or "other") as
Step 3 of setting up a patrol in `farming-order.html` — this is stored
on the order (`cropType`) and genuinely changes which color ranges
`color_ripeness_detector.py` looks for, since different crops ripen
through different colors (bananas go green→yellow, never red, for
example). `inference_server.py` looks up the order's crop type via a
small unauthenticated endpoint (`/api/robot/farming-order/:id/crop-type`
— deliberately returns *only* the crop type, not the whole order) before
running detection. This was tested end-to-end: a farmer picking
"banana" on the web form was confirmed to produce banana-preset
detections (`BA001`, `BA002`, ...) all the way through, not tomato
defaults silently used instead.

**What's still genuinely a separate, bigger undertaking**: a real
*trained* model (rather than the color-based one) needs you to collect
and label hundreds of your own crop photos, then train on Google
Colab's free GPU — `ml/train_yolo.py` has the exact ready-to-use script
for that, but the data collection and labeling is real work on your
end, not something code can shortcut.

## The big feature batch (ratings, history, chat, fleet, analytics, and more)

Everything below is real, tested, working code — the server actually
boots and serves every new file correctly.

**Quick wins:**
- **Star rating + feedback** — appears automatically once an order hits
  "Delivered" on `customer-tracking.html` and `indoor-tracking.html`.
  Saved via `POST /api/orders/:id/rate`.
- **Order history** — `history.html`, reachable from every order page.
  Pulls from `GET /api/orders/history`, across outdoor/indoor/farming.
- **Delivery proof photo** — admins can attach a photo to any order from
  a new panel on the dashboard (`POST /api/orders/:id/delivery-photo`);
  it shows up automatically on the customer's delivered banner. Real
  ESP32-CAM auto-capture-on-delivery isn't wired in yet — this is the
  manual stand-in, ready for that later.
- **Language switcher** — English/French/Kinyarwanda, top-right on every
  page. Fully wired on `login.html` and `register.html` as the working
  demonstration; extending it to another page means adding
  `data-i18n="key"` to its elements and matching entries to the three
  dictionaries in `public/assets/i18n.js`.

**Medium features:**
- **Admin analytics** — `admin-analytics.html`, linked from the
  dashboard. Real canvas-drawn charts: deliveries/day, battery trend,
  crop ripeness trend, average delivery time, average rating.
- **STAT priority** — a checkbox on both the outdoor and indoor order
  forms. Priority orders float to the top of the admin queue and get a
  red highlight.
- **In-app chat** — a floating chat button on every tracking page,
  talking to a matching panel on the admin dashboard, over the same
  Socket.IO connection everything else already uses.
- **Fleet panel** — admin dashboard now shows a "Fleet" list instead of
  assuming one robot. Only one exists today (`robots.json` seeds with
  it), but every telemetry event tags a `robotId`, so a second robot
  reporting in would just appear in the list automatically.

**Bigger items — real but intentionally scoped:**
- **PWA** — `manifest.json` + real generated icons + `service-worker.js`
  caching the app shell for offline access to already-visited pages.
  Auto-registered on every page via `transitions.js`. **Push
  notifications are not included** — those need a VAPID key pair and a
  live HTTPS domain (they don't work over plain `http://localhost` in
  most browsers), which is a separate setup step for whenever this is
  actually deployed somewhere public.
- **Payment** — a "Pay with Mobile Money" button on the customer
  tracking page, calling `POST /api/orders/:id/pay`. This is explicitly
  a **stub** — it logs what it *would* charge to the console and marks
  the order paid, but never contacts a real payment provider. Real
  Mobile Money integration needs an actual merchant account and API
  credentials from a provider (e.g. MTN MoMo, Airtel Money) — that's a
  business step, not a code step, so this is ready to plug real
  credentials into once you have them.
- **Crop-detection AI** — no longer purely simulated. See `ml/` for a
  real, tested color-based detector working today, plus the ready-to-use
  upgrade script for training a real model once you have your own
  labeled photos.
- **Traffic light detection** — a real, tested assistive indicator on
  the admin dashboard (`ml/traffic_light_detector.py` +
  `ml/traffic_light_server.py`, see `ml/traffic-light-README.md`).
  Genuinely detects red/yellow/green using a pretrained model (no
  training needed) — deliberately does NOT predict timing, since that's
  not something a camera can reliably know. Heavier install than the
  crop AI (pulls in PyTorch) — read the setup notes before installing.

## Going live later

`users.json` is fine for learning and testing, but for a real deployment
with many users, swap it for a real database (e.g. PostgreSQL or MongoDB)
— the shape of `loadUsers()`/`saveUsers()` in `server.js` is written so
that swap only touches those two functions, not the routes that use them.
