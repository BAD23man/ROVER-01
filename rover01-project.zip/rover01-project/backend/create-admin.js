// Run this ONCE to create your first admin account:
//   node create-admin.js
//
// Edit the three values below first.

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const adminName     = 'Admin';
const adminEmail    = 'admin@rover01.com';
const adminPassword = 'changeme123'; // change this before running, and again after first login

const USERS_FILE = path.join(__dirname, 'users.json');
let users = fs.existsSync(USERS_FILE) ? JSON.parse(fs.readFileSync(USERS_FILE)) : [];

if (users.find(u => u.email.toLowerCase() === adminEmail.toLowerCase())) {
  console.log('An account with that email already exists. Nothing created.');
} else {
  users.push({
    id: 'USR-' + Math.floor(10000 + Math.random() * 89999),
    fullName: adminName,
    email: adminEmail,
    phone: '',
    passwordHash: bcrypt.hashSync(adminPassword, 10),
    role: 'admin',
    createdAt: Date.now()
  });
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  console.log(`Admin account created: ${adminEmail}`);
  console.log('You can now log in at http://localhost:4000/admin-login.html');
}
