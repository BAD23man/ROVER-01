@echo off
title ROVER-01 Server
cd /d "%~dp0backend"
echo Starting ROVER-01 server...
echo.
npm start
pause
